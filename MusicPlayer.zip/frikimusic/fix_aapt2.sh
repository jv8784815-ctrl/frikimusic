#!/bin/bash
echo "Buscando binarios intrusos..."
while true; do
  # Busca el aapt2 que Gradle acaba de descargar
  INTRUSO=$(find $HOME/projects/musicajeje/.gradle/caches/transforms-2 -name "aapt2" -type f ! -loader 2>/dev/null)
  
  for f in $INTRUSO; do
    # Si no es un enlace simbólico, lo reemplazamos
    if [ ! -L "$f" ]; then
      echo "¡Cazado! Reemplazando $f"
      rm "$f"
      ln -s /usr/bin/aapt2 "$f"
    fi
  done
  sleep 1
done
