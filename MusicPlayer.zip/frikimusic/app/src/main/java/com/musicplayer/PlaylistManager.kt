package com.musicplayer

import android.content.Context
import org.json.JSONArray

object PlaylistManager {

    private const val PREFS_NAME   = "frikimusic_playlists"
    private const val PLAYLISTS_KEY = "playlists"

    private val playlists = ArrayList<Playlist>()

    fun load(context: Context) {
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PLAYLISTS_KEY, null) ?: return
        try {
            val arr = JSONArray(json)
            playlists.clear()
            for (i in 0 until arr.length()) {
                playlists.add(Playlist.fromJson(arr.getJSONObject(i)))
            }
        } catch (e: Exception) { }
    }

    private fun save(context: Context) {
        val arr = JSONArray()
        for (p in playlists) arr.put(p.toJson())
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(PLAYLISTS_KEY, arr.toString()).apply()
    }

    fun getAll(): ArrayList<Playlist> = playlists

    fun create(context: Context, name: String): Playlist {
        val pl = Playlist(id = System.currentTimeMillis().toString(), name = name)
        playlists.add(pl)
        save(context)
        return pl
    }

    fun delete(context: Context, id: String) {
        playlists.removeAll { it.id == id }
        save(context)
    }

    fun addSong(context: Context, playlistId: String, song: Song): Boolean {
        val pl = playlists.find { it.id == playlistId } ?: return false
        if (pl.songs.any { it.path == song.path && it.videoId == song.videoId }) return false
        pl.songs.add(song)
        save(context)
        return true
    }

    fun removeSong(context: Context, playlistId: String, songIndex: Int) {
        val pl = playlists.find { it.id == playlistId } ?: return
        if (songIndex < 0 || songIndex >= pl.songs.size) return
        pl.songs.removeAt(songIndex)
        save(context)
    }

    fun getById(id: String): Playlist? = playlists.find { it.id == id }
}