package com.musicplayer

import org.json.JSONArray
import org.json.JSONObject

data class Playlist(
    val id: String,
    val name: String,
    val songs: ArrayList<Song> = ArrayList()
) {
    fun toJson(): JSONObject {
        val songsArr = JSONArray()
        for (s in songs) {
            songsArr.put(JSONObject().apply {
                put("title",       s.title)
                put("artist",      s.artist)
                put("path",        s.path)
                put("duration",    s.duration)
                put("isStreaming", s.isStreaming)
                put("videoId",     s.videoId)
            })
        }
        return JSONObject().apply {
            put("id",    id)
            put("name",  name)
            put("songs", songsArr)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): Playlist {
            val songs = ArrayList<Song>()
            val arr = obj.optJSONArray("songs") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i)
                songs.add(Song(
                    title       = s.getString("title"),
                    artist      = s.getString("artist"),
                    path        = s.getString("path"),
                    duration    = s.getLong("duration"),
                    isStreaming = s.optBoolean("isStreaming", false),
                    videoId     = s.optString("videoId", "")
                ))
            }
            return Playlist(
                id    = obj.getString("id"),
                name  = obj.getString("name"),
                songs = songs
            )
        }
    }
}