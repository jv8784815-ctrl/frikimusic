package com.musicplayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever

data class Song(
    val title: String,
    val artist: String,
    val path: String,
    val duration: Long,
    val isStreaming: Boolean = false,
    val videoId: String = ""
) {
    fun getArtistDisplay(): String {
        return if (artist == "<unknown>" || artist.isBlank()) "Artista desconocido" else artist
    }

    fun getTitleDisplay(): String {
        return if (title == "<unknown>" || title.isBlank()) {
            if (isStreaming) "Streaming"
            else path.substringAfterLast("/").substringBeforeLast(".").ifEmpty { title }
        } else title
    }

    fun hasMetadata(): Boolean {
        val t = title != "<unknown>" && title.isNotBlank()
        val a = artist != "<unknown>" && artist.isNotBlank()
        return t && a
    }

    fun getAlbumArt(): Bitmap? {
        if (isStreaming && videoId.isNotEmpty()) {
            return try {
                val url = java.net.URL("https://img.youtube.com/vi/$videoId/hqdefault.jpg")
                val conn = url.openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val bmp = BitmapFactory.decodeStream(conn.inputStream)
                conn.disconnect()
                bmp
            } catch (e: Exception) {
                null
            }
        }

        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(path)
            val bytes = retriever.embeddedPicture
            retriever.release()
            if (bytes != null) BitmapFactory.decodeByteArray(bytes, 0, bytes.size) else null
        } catch (e: Exception) {
            null
        }
    }

    fun getDurationStr(): String {
        val s = (duration / 1000) % 60
        val m = (duration / 60000) % 60
        return "%d:%02d".format(m, s)
    }
}