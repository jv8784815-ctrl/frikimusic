package com.musicplayer

import android.content.Context
import android.view.*
import android.widget.BaseAdapter
import android.widget.TextView

class PlaylistAdapter(
    private val context: Context,
    private val playlists: ArrayList<Playlist>
) : BaseAdapter() {

    private val inflater = LayoutInflater.from(context)

    override fun getCount() = playlists.size
    override fun getItem(pos: Int) = playlists[pos]
    override fun getItemId(pos: Int) = pos.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: inflater.inflate(R.layout.item_playlist, parent, false)
        val pl = playlists[position]
        view.findViewById<TextView>(R.id.tvPlaylistItemName).text = pl.name
        val count = pl.songs.size
        view.findViewById<TextView>(R.id.tvPlaylistItemCount).text =
            if (count == 1) "1 canción" else "$count canciones"
        return view
    }
}