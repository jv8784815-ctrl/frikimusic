package com.musicplayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.mpatric.mp3agic.ID3v24Tag
import com.mpatric.mp3agic.Mp3File
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Id3Writer {

    /**
     * Escribe tags ID3v2 (título, artista, imagen) al MP3 en [file].
     * Reemplaza el archivo original con el etiquetado.
     */
    fun tag(file: File, title: String, artist: String, videoId: String) {
        try {
            val mp3 = Mp3File(file)
            val tag = ID3v24Tag()

            tag.title  = title.take(200)
            tag.artist = artist.take(200)
            tag.album  = artist.take(200)   // álbum = artista para que aparezca algo

            // Imagen de thumbnail de YouTube
            val art = fetchThumbnail(videoId)
            if (art != null) {
                tag.setAlbumImage(art, "image/jpeg")
            }

            mp3.id3v2Tag = tag

            val tmp = File(file.parent, file.nameWithoutExtension + "_tagged.mp3")
            mp3.save(tmp.absolutePath)

            // Reemplazar original con el etiquetado
            file.delete()
            tmp.renameTo(file)
        } catch (e: Exception) {
            // Si falla el tagging no rompemos la descarga — el archivo sin tags queda igual
            e.printStackTrace()
        }
    }

    private fun fetchThumbnail(videoId: String): ByteArray? {
        // Intentar maxresdefault, luego hqdefault
        for (quality in listOf("maxresdefault", "hqdefault", "mqdefault")) {
            try {
                val conn = URL("https://img.youtube.com/vi/$videoId/$quality.jpg")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.connect()
                if (conn.responseCode == 200) {
                    val bmp = BitmapFactory.decodeStream(conn.inputStream)
                    conn.disconnect()
                    if (bmp != null) {
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        return out.toByteArray()
                    }
                } else {
                    conn.disconnect()
                }
            } catch (e: Exception) { }
        }
        return null
    }
}