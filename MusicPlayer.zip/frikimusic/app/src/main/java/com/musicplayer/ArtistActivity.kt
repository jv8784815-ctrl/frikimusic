package com.musicplayer

import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.*
import java.net.*

class ArtistActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    data class Track(val title: String, val duration: String, val imageUrl: String, val videoId: String)
    data class Album(val title: String, val year: String, val imageUrl: String, val browseId: String, val type: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val artistName = intent.getStringExtra("artist_name") ?: run { finish(); return }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        scroll.addView(root)
        setContentView(scroll)

        val headerFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260))
        }
        val imgHero = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.parseColor("#1A1A1A"))
        }
        headerFrame.addView(imgHero)

        val gradient = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#44000000"), Color.parseColor("#CC000000"), Color.BLACK)
            )
        }
        headerFrame.addView(gradient)

        val btnBack = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.parseColor("#44000000"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40)).apply { topMargin = dp(24); leftMargin = dp(16) }
        }
        btnBack.setOnClickListener { finish() }
        headerFrame.addView(btnBack)

        val tvName = TextView(this).apply {
            text = artistName
            setTextColor(Color.WHITE)
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
                leftMargin = dp(20); bottomMargin = dp(20)
            }
        }
        headerFrame.addView(tvName)
        root.addView(headerFrame)

        val tvSubs = TextView(this).apply {
            text = "..."
            setTextColor(Color.parseColor("#888888"))
            textSize = 13f
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        root.addView(tvSubs)

        root.addView(sectionTitle("Canciones populares"))
        val tracksContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tracksContainer.addView(TextView(this).apply {
            text = "Cargando..."; setTextColor(Color.parseColor("#555555"))
            textSize = 13f; setPadding(dp(20), dp(8), dp(20), dp(8))
        })
        root.addView(tracksContainer)

        root.addView(sectionTitle("Discografía"))
        val albumsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        albumsContainer.addView(TextView(this).apply {
            text = "Cargando..."; setTextColor(Color.parseColor("#555555"))
            textSize = 13f; setPadding(dp(20), dp(8), dp(20), dp(40))
        })
        root.addView(albumsContainer)

        Thread {
            fetchArtistFromYTMusic(artistName) { imageUrl, subs, tracks, albums ->
                handler.post {
                    if (imageUrl.isNotEmpty()) loadBitmap(imageUrl) { imgHero.setImageBitmap(it) }
                    tvSubs.text = subs.ifEmpty { "" }

                    tracksContainer.removeAllViews()
                    if (tracks.isEmpty()) {
                        tracksContainer.addView(TextView(this).apply {
                            text = "Sin canciones disponibles"
                            setTextColor(Color.parseColor("#555555"))
                            setPadding(dp(20), dp(8), dp(20), dp(8))
                        })
                    } else {
                        tracks.forEachIndexed { i, t -> tracksContainer.addView(buildTrackRow(i + 1, t, artistName)) }
                    }

                    albumsContainer.removeAllViews()
                    if (albums.isEmpty()) {
                        albumsContainer.addView(TextView(this).apply {
                            text = "Sin álbumes disponibles"
                            setTextColor(Color.parseColor("#555555"))
                            setPadding(dp(20), dp(8), dp(20), dp(40))
                        })
                    } else {
                        albums.forEach { a -> albumsContainer.addView(buildAlbumRow(a, artistName)) }
                        albumsContainer.addView(View(this).apply {
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40))
                        })
                    }
                }
            }
        }.start()
    }

    private fun fetchArtistFromYTMusic(
        name: String,
        cb: (imageUrl: String, subs: String, tracks: List<Track>, albums: List<Album>) -> Unit
    ) {
        try {
            val searchBody = JSONObject().apply {
                put("query", name)
                put("params", "EgWKAQIgAWoKEAMQBBAJEAoQBQ%3D%3D")
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "WEB_REMIX")
                        put("clientVersion", "1.20231219.01.00")
                        put("hl", "es")
                    })
                })
            }.toString()

            val sConn = URL("https://music.youtube.com/youtubei/v1/search?prettyPrint=false").openConnection() as HttpURLConnection
            sConn.requestMethod = "POST"
            sConn.setRequestProperty("Content-Type", "application/json")
            sConn.setRequestProperty("User-Agent", "Mozilla/5.0")
            sConn.setRequestProperty("Referer", "https://music.youtube.com/")
            sConn.doOutput = true; sConn.connectTimeout = 10000; sConn.readTimeout = 10000
            sConn.outputStream.write(searchBody.toByteArray())
            val sResp = JSONObject(sConn.inputStream.bufferedReader().readText())
            sConn.disconnect()

            var browseId = ""
            var imageUrl = ""

            val contents = sResp.optJSONObject("contents")
                ?.optJSONObject("tabbedSearchResultsRenderer")
                ?.optJSONArray("tabs")?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")?.optJSONArray("contents")

            if (contents != null) {
                outer@ for (i in 0 until contents.length()) {
                    val items = contents.optJSONObject(i)?.optJSONObject("musicShelfRenderer")
                        ?.optJSONArray("contents") ?: continue
                    for (j in 0 until items.length()) {
                        val item = items.optJSONObject(j)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                        val flexCols = item.optJSONArray("flexColumns") ?: continue
                        val subtitle = flexCols.optJSONObject(1)
                            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                            ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)
                            ?.optString("text") ?: ""
                        if (!subtitle.lowercase().contains("artist") && !subtitle.lowercase().contains("artista")) continue
                        browseId = item.optJSONObject("navigationEndpoint")
                            ?.optJSONObject("browseEndpoint")?.optString("browseId") ?: ""
                        val thumbnails = item.optJSONObject("thumbnail")
                            ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail")
                            ?.optJSONArray("thumbnails")
                        imageUrl = thumbnails?.optJSONObject(thumbnails.length() - 1)?.optString("url") ?: ""
                        if (browseId.isNotEmpty()) break@outer
                    }
                }
            }

            if (browseId.isEmpty()) { cb(imageUrl, "", emptyList(), emptyList()); return }

            val browseBody = JSONObject().apply {
                put("browseId", browseId)
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "WEB_REMIX")
                        put("clientVersion", "1.20231219.01.00")
                        put("hl", "es")
                    })
                })
            }.toString()

            val bConn = URL("https://music.youtube.com/youtubei/v1/browse?prettyPrint=false").openConnection() as HttpURLConnection
            bConn.requestMethod = "POST"
            bConn.setRequestProperty("Content-Type", "application/json")
            bConn.setRequestProperty("User-Agent", "Mozilla/5.0")
            bConn.setRequestProperty("Referer", "https://music.youtube.com/")
            bConn.doOutput = true; bConn.connectTimeout = 10000; bConn.readTimeout = 10000
            bConn.outputStream.write(browseBody.toByteArray())
            val bResp = JSONObject(bConn.inputStream.bufferedReader().readText())
            bConn.disconnect()

            val headerImg = bResp.optJSONObject("header")
                ?.optJSONObject("musicImmersiveHeaderRenderer")
                ?.optJSONObject("thumbnail")?.optJSONObject("musicThumbnailRenderer")
                ?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
                ?.let { arr -> arr.optJSONObject(arr.length() - 1)?.optString("url") }
            if (!headerImg.isNullOrEmpty()) imageUrl = headerImg

            val subs = bResp.optJSONObject("header")
                ?.optJSONObject("musicImmersiveHeaderRenderer")
                ?.optJSONObject("subscriptionButton")
                ?.optJSONObject("subscribeButtonRenderer")
                ?.optJSONObject("subscriberCountText")
                ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""

            val tracks = mutableListOf<Track>()
            val albums = mutableListOf<Album>()

            val sections = bResp.optJSONObject("contents")
                ?.optJSONObject("singleColumnBrowseResultsRenderer")
                ?.optJSONArray("tabs")?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")?.optJSONArray("contents")

            if (sections != null) {
                for (si in 0 until sections.length()) {
                    val section = sections.optJSONObject(si) ?: continue

                    val musicShelf = section.optJSONObject("musicShelfRenderer")
                    if (musicShelf != null) {
                        val items = musicShelf.optJSONArray("contents") ?: continue
                        for (ii in 0 until minOf(items.length(), 5)) {
                            val item = items.optJSONObject(ii)?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                            val flex = item.optJSONArray("flexColumns") ?: continue
                            val title = flex.optJSONObject(0)
                                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                                ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)
                                ?.optString("text") ?: continue
                            val dur = flex.optJSONObject(1)
                                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                                ?.optJSONObject("text")?.optJSONArray("runs")
                                ?.let { runs -> (0 until runs.length()).map { runs.getJSONObject(it).optString("text") }.find { it.contains(":") } } ?: ""
                            val thumbArr = item.optJSONObject("thumbnail")
                                ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail")
                                ?.optJSONArray("thumbnails")
                            val thumb = thumbArr?.optJSONObject(thumbArr.length() - 1)?.optString("url") ?: ""
                            val videoId = item.optJSONObject("overlay")
                                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                                ?.optJSONObject("content")?.optJSONObject("musicPlayButtonRenderer")
                                ?.optJSONObject("playNavigationEndpoint")?.optJSONObject("watchEndpoint")
                                ?.optString("videoId") ?: item.optJSONArray("flexColumns")
                                ?.optJSONObject(0)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                                ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)
                                ?.optJSONObject("navigationEndpoint")?.optJSONObject("watchEndpoint")
                                ?.optString("videoId") ?: ""
                            tracks.add(Track(title, dur, thumb, videoId))
                        }
                    }

                    val carousel = section.optJSONObject("musicCarouselShelfRenderer") ?: continue
                    val carouselItems = carousel.optJSONArray("contents") ?: continue
                    val headerText = carousel.optJSONObject("header")
                        ?.optJSONObject("musicCarouselShelfBasicHeaderRenderer")
                        ?.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)
                        ?.optString("text") ?: ""

                    val isAlbumSection = headerText.lowercase().let {
                        it.contains("album") || it.contains("single") || it.contains("disco") || it.contains("lanzamiento")
                    }
                    if (!isAlbumSection) continue

                    for (ai in 0 until minOf(carouselItems.length(), 10)) {
                        val aItem = carouselItems.optJSONObject(ai)
                            ?.optJSONObject("musicTwoRowItemRenderer") ?: continue
                        val aTitle = aItem.optJSONObject("title")?.optJSONArray("runs")
                            ?.optJSONObject(0)?.optString("text") ?: continue

                        val subtitle = aItem.optJSONObject("subtitle")?.optJSONArray("runs")
                        val subtitleTexts = subtitle?.let { runs ->
                            (0 until runs.length()).map { runs.getJSONObject(it).optString("text") }
                        } ?: emptyList()

                        // Año: buscar el primer texto que sea 4 dígitos
                        val year = subtitleTexts.find { it.matches(Regex("\\d{4}")) } ?: ""

                        // Tipo: buscar "Album", "Single", "EP" en el subtitle
                        val aType = subtitleTexts.find { t ->
                            t.lowercase().let { it == "album" || it == "single" || it == "ep" || it == "álbum" }
                        } ?: "Álbum"

                        // Solo incluir si tiene browseId (es un álbum real navegable)
                        val aBrowseId = aItem.optJSONObject("navigationEndpoint")
                            ?.optJSONObject("browseEndpoint")?.optString("browseId") ?: ""
                        if (aBrowseId.isEmpty()) continue

                        // Thumbnail del álbum (no del artista)
                        val aThumbs = aItem.optJSONObject("thumbnailRenderer")
                            ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail")
                            ?.optJSONArray("thumbnails")
                        val aThumb = aThumbs?.optJSONObject(aThumbs.length() - 1)?.optString("url") ?: ""

                        albums.add(Album(aTitle, year, aThumb, aBrowseId, aType))
                    }
                }
            }

            cb(imageUrl, subs, tracks, albums)
        } catch (e: Exception) {
            handler.post { Toast.makeText(this, "Error: ${e.message?.take(60)}", Toast.LENGTH_LONG).show() }
            cb("", "", emptyList(), emptyList())
        }
    }

    private fun buildTrackRow(num: Int, track: Track, artistName: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        row.addView(TextView(this).apply {
            text = "$num"
            setTextColor(Color.parseColor("#555555"))
            textSize = 14f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(28), LinearLayout.LayoutParams.WRAP_CONTENT)
        })
        val img = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).also { it.marginStart = dp(8); it.marginEnd = dp(12) }
            setBackgroundColor(Color.parseColor("#1C1C1C"))
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        row.addView(img)
        if (track.imageUrl.isNotEmpty()) loadBitmap(track.imageUrl) { img.setImageBitmap(it) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(TextView(this).apply {
            text = track.title
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        row.addView(col)
        if (track.duration.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = track.duration
                setTextColor(Color.parseColor("#555555"))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.marginStart = dp(8) }
            })
        }
        row.setOnClickListener {
            if (track.videoId.isNotEmpty()) {
                sendBroadcast(Intent("com.musicplayer.PLAY_STREAM").apply {
                    putExtra("title", track.title)
                    putExtra("artist", artistName)
                    putExtra("videoId", track.videoId)
                    putExtra("duration", 0L)
                })
                Toast.makeText(this, "▶ ${track.title}", Toast.LENGTH_SHORT).show()
            }
        }
        return row
    }

    private fun buildAlbumRow(album: Album, artistName: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        val img = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).also { it.marginEnd = dp(14) }
            setBackgroundColor(Color.parseColor("#1C1C1C"))
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        row.addView(img)
        if (album.imageUrl.isNotEmpty()) loadBitmap(album.imageUrl) { img.setImageBitmap(it) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(TextView(this).apply {
            text = album.title
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            val label = when { album.type.lowercase().contains("single") -> "Single" else -> "Álbum" }
            text = if (album.year.isNotEmpty()) "$label · ${album.year}" else label
            setTextColor(Color.parseColor("#666666"))
            textSize = 12f
            setPadding(0, dp(3), 0, 0)
        })
        row.addView(col)

        row.setOnClickListener {
            startActivity(Intent(this, AlbumActivity::class.java).apply {
                putExtra("browse_id", album.browseId)
                putExtra("album_title", album.title)
                putExtra("album_art", album.imageUrl)
                putExtra("artist_name", artistName)
                putExtra("album_year", album.year)
            })
        }

        return row
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 17f
        setTypeface(null, Typeface.BOLD)
        setPadding(dp(20), dp(20), dp(20), dp(6))
    }

    private fun loadBitmap(url: String, cb: (Bitmap) -> Unit) {
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val bmp = BitmapFactory.decodeStream(conn.inputStream)
                conn.disconnect()
                if (bmp != null) handler.post { cb(bmp) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}