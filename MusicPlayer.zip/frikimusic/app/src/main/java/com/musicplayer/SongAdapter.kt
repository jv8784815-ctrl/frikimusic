package com.musicplayer

import android.app.AlertDialog
import android.content.Context
import android.view.*
import android.widget.*

class SongAdapter(
    private val context: Context,
    private val songs: ArrayList<Song>,
    private val showAddToPlaylist: Boolean = true
) : BaseAdapter() {

    private val inflater = LayoutInflater.from(context)

    override fun getCount() = songs.size
    override fun getItem(pos: Int) = songs[pos]
    override fun getItemId(pos: Int) = pos.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: inflater.inflate(R.layout.item_song, parent, false)
        val song = songs[position]
        val tvTitle    = view.findViewById<TextView>(R.id.tvTitle)
        val tvArtist   = view.findViewById<TextView>(R.id.tvArtist)
        val tvDuration = view.findViewById<TextView>(R.id.tvDuration)
        val imgThumb   = view.findViewById<ImageView>(R.id.imgThumb)
        val btnAdd     = view.findViewById<ImageButton>(R.id.btnAddToPlaylist)

        tvTitle.text    = song.getTitleDisplay()
        tvArtist.text   = song.getArtistDisplay()
        tvDuration.text = song.getDurationStr()

        // Thumbnail
        imgThumb.setImageResource(android.R.drawable.ic_media_play)
        imgThumb.tag = song.path.ifEmpty { song.videoId }
        Thread {
            val art = song.getAlbumArt()
            val tag = song.path.ifEmpty { song.videoId }
            if (imgThumb.tag == tag) {
                (parent.context as android.app.Activity).runOnUiThread {
                    if (art != null) {
                        imgThumb.setImageBitmap(art)
                        imgThumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    }
                }
            }
        }.start()

        // Botón añadir a playlist
        if (showAddToPlaylist) {
            btnAdd.visibility = View.VISIBLE
            btnAdd.setOnClickListener {
                showAddToPlaylistDialog(context, song)
            }
        } else {
            btnAdd.visibility = View.GONE
        }

        return view
    }

    private fun showAddToPlaylistDialog(context: Context, song: Song) {
        PlaylistManager.load(context)
        val playlists = PlaylistManager.getAll()

        if (playlists.isEmpty()) {
            // No hay playlists: ofrecer crear una
            AlertDialog.Builder(context)
                .setTitle("Sin playlists")
                .setMessage("Aún no tienes ninguna playlist.\n¿Quieres crear una ahora?")
                .setPositiveButton("Crear") { _, _ ->
                    val editText = EditText(context).apply {
                        hint = "Nombre de la playlist"
                        setPadding(48, 24, 48, 24)
                    }
                    AlertDialog.Builder(context)
                        .setTitle("Nueva playlist")
                        .setView(editText)
                        .setPositiveButton("Crear") { _, _ ->
                            val name = editText.text.toString().trim()
                            if (name.isNotEmpty()) {
                                val pl = PlaylistManager.create(context, name)
                                val added = PlaylistManager.addSong(context, pl.id, song)
                                Toast.makeText(
                                    context,
                                    if (added) "✓ Añadida a \"${pl.name}\"" else "Ya está en la playlist",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }

        val names = playlists.map { "${it.name} (${it.songs.size})" }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle("Añadir a playlist")
            .setItems(names) { _, which ->
                val pl = playlists[which]
                val added = PlaylistManager.addSong(context, pl.id, song)
                Toast.makeText(
                    context,
                    if (added) "✓ Añadida a \"${pl.name}\"" else "Ya está en \"${pl.name}\"",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNeutralButton("Nueva playlist ＋") { _, _ ->
                val editText = EditText(context).apply {
                    hint = "Nombre de la playlist"
                    setPadding(48, 24, 48, 24)
                }
                AlertDialog.Builder(context)
                    .setTitle("Nueva playlist")
                    .setView(editText)
                    .setPositiveButton("Crear") { _, _ ->
                        val name = editText.text.toString().trim()
                        if (name.isNotEmpty()) {
                            val pl = PlaylistManager.create(context, name)
                            PlaylistManager.addSong(context, pl.id, song)
                            Toast.makeText(
                                context,
                                "✓ Playlist \"${pl.name}\" creada con la canción",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .show()
    }
}