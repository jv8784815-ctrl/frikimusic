package com.musicplayer

import android.Manifest
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.*
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class PlaylistActivity : AppCompatActivity() {

    private lateinit var tvPlaylistName: TextView
    private lateinit var tvSongCount: TextView
    private lateinit var listView: ListView
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnPlayOrder: ImageButton
    private lateinit var btnDownloadAll: ImageButton

    private var playlistId = ""
    private var musicService: MusicService? = null
    private var isBound = false
    private val handler = Handler(Looper.getMainLooper())

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            musicService = (binder as MusicService.MusicBinder).getService(); isBound = true
        }
        override fun onServiceDisconnected(name: ComponentName) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlist)

        playlistId = intent.getStringExtra("playlist_id") ?: run { finish(); return }

        tvPlaylistName = findViewById(R.id.tvPlaylistName)
        tvSongCount    = findViewById(R.id.tvSongCount)
        listView       = findViewById(R.id.listViewPlaylist)
        btnShuffle     = findViewById(R.id.btnShufflePlaylist)
        btnPlayOrder   = findViewById(R.id.btnPlayOrderPlaylist)
        btnDownloadAll = findViewById(R.id.btnDownloadAll)

        PlaylistManager.load(this)
        refreshUI()

        findViewById<ImageButton>(R.id.btnBackPlaylist).setOnClickListener { finish() }

        btnShuffle.setOnClickListener {
            val pl = PlaylistManager.getById(playlistId) ?: return@setOnClickListener
            playList(ArrayList(pl.songs.shuffled()))
        }
        btnPlayOrder.setOnClickListener {
            val pl = PlaylistManager.getById(playlistId) ?: return@setOnClickListener
            playList(pl.songs)
        }
        btnDownloadAll.setOnClickListener {
            val pl = PlaylistManager.getById(playlistId) ?: return@setOnClickListener
            confirmDownloadAll(pl)
        }

        listView.setOnItemClickListener { _, _, pos, _ ->
            val pl = PlaylistManager.getById(playlistId) ?: return@setOnItemClickListener
            playList(pl.songs, pos)
        }

        listView.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this)
                .setTitle("Quitar canción")
                .setMessage("¿Quitar esta canción de la playlist?")
                .setPositiveButton("Quitar") { _, _ ->
                    PlaylistManager.removeSong(this, playlistId, pos)
                    refreshUI()
                }
                .setNegativeButton("Cancelar", null).show()
            true
        }

        startService(Intent(this, MusicService::class.java))
        bindService(Intent(this, MusicService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun playList(songs: ArrayList<Song>, startAt: Int = 0) {
        val svc = musicService
        if (svc != null) { svc.setSongList(songs); svc.playSongAt(startAt) }
        else handler.postDelayed({ musicService?.setSongList(songs); musicService?.playSongAt(startAt) }, 600)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun refreshUI() {
        val pl = PlaylistManager.getById(playlistId) ?: run { finish(); return }
        tvPlaylistName.text = pl.name
        val n = pl.songs.size
        val hasEnough = n >= 7
        tvSongCount.text = if (hasEnough) "$n canciones"
                           else "$n / 7  —  agrega ${7 - n} más para desbloquear controles"
        btnShuffle.visibility     = if (hasEnough) View.VISIBLE else View.GONE
        btnPlayOrder.visibility   = if (hasEnough) View.VISIBLE else View.GONE
        btnDownloadAll.visibility = if (hasEnough) View.VISIBLE else View.GONE
        // showAddToPlaylist=false para que no aparezca el botón + dentro de la playlist
        listView.adapter = SongAdapter(this, pl.songs, showAddToPlaylist = false)
    }

    private fun confirmDownloadAll(pl: Playlist) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 99)
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Guardar en Descargas")
            .setMessage("Se guardarán ${pl.songs.size} canciones en la carpeta Descargas de tu teléfono.")
            .setPositiveButton("Descargar") { _, _ -> doDownloadAll(pl) }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun doDownloadAll(pl: Playlist) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Descargando…")
            .setMessage("0 / ${pl.songs.size}")
            .setCancelable(false).create()
        dialog.show()

        Thread {
            var done = 0; var failed = 0
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()
            val scannedPaths = mutableListOf<String>()

            for (song in pl.songs) {
                try {
                    val fileName = sanitize(song.getTitleDisplay()) + ".mp3"
                    val dest = File(downloadsDir, fileName)

                    if (!dest.exists()) {
                        if (!song.isStreaming) {
                            File(song.path).copyTo(dest, overwrite = true)
                        } else {
                            val url = getStreamUrl(song.videoId)
                            if (url != null) {
                                downloadFile(url, dest)
                                // Escribir tags ID3: título, artista e imagen
                                Id3Writer.tag(
                                    dest,
                                    song.getTitleDisplay(),
                                    song.getArtistDisplay(),
                                    song.videoId
                                )
                            } else {
                                failed++
                                updateDialog(dialog, done, pl.songs.size, "✗ ${song.getTitleDisplay()}")
                                continue
                            }
                        }
                    }

                    scannedPaths.add(dest.absolutePath)
                    done++
                    updateDialog(dialog, done, pl.songs.size, "✓ ${song.getTitleDisplay()}")
                } catch (e: Exception) {
                    failed++
                    updateDialog(dialog, done, pl.songs.size, "✗ error: ${e.message?.take(40)}")
                }
            }

            // ── Notificar al MediaScanner para que aparezcan en la app ──
            if (scannedPaths.isNotEmpty()) {
                MediaScannerConnection.scanFile(
                    this,
                    scannedPaths.toTypedArray(),
                    null
                ) { _, _ -> }

                // Avisar a MainActivity que recargue la lista
                handler.post {
                    sendBroadcast(Intent("com.musicplayer.SONG_ADDED"))
                }
            }

            handler.post {
                dialog.dismiss()
                AlertDialog.Builder(this)
                    .setTitle("Listo")
                    .setMessage(
                        if (failed == 0) "✅ $done canciones guardadas en Descargas.\nYa aparecen en la lista principal."
                        else "✅ $done guardadas · ❌ $failed fallidas."
                    )
                    .setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun updateDialog(d: AlertDialog, done: Int, total: Int, last: String) {
        handler.post { d.setMessage("$done / $total\n$last") }
    }

    private fun sanitize(name: String) =
        name.replace(Regex("[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ _-]"), "_").take(80)

    private fun getStreamUrl(videoId: String): String? {
        try {
            val body = org.json.JSONObject().apply {
                put("url", "https://www.youtube.com/watch?v=$videoId")
                put("quality", "128")
                put("apikey", "friki_ebddef50f2754a0182a51d781006fc4c")
            }.toString()
            val conn = URL("http://64.20.54.50:30325/api/ytmp3").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true; conn.connectTimeout = 15000; conn.readTimeout = 300000
            conn.outputStream.write(body.toByteArray())
            val resp = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            if (resp.optBoolean("success") && resp.has("dl")) return resp.getString("dl")
        } catch (e: Exception) { }
        try {
            val body = org.json.JSONObject().apply {
                put("url", "https://www.youtube.com/watch?v=$videoId")
                put("format", "mp3")
            }.toString()
            val conn = URL("https://yt-downloader-by-josexo-and-abejitadiceiwiwiwi.vercel.app/api/app-download")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true; conn.connectTimeout = 30000; conn.readTimeout = 120000
            conn.outputStream.write(body.toByteArray())
            val resp = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            val rel = resp.optString("url").takeIf { it.isNotEmpty() } ?: return null
            return "https://yt-downloader-by-josexo-and-abejitadiceiwiwiwi.vercel.app$rel"
        } catch (e: Exception) { }
        return null
    }

    private fun downloadFile(url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000; conn.readTimeout = 120000; conn.connect()
        conn.inputStream.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        conn.disconnect()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 99 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED)
            PlaylistManager.getById(playlistId)?.let { confirmDownloadAll(it) }
    }

    override fun onResume() { super.onResume(); refreshUI() }
    override fun onDestroy() {
        super.onDestroy()
        if (isBound) { unbindService(serviceConnection); isBound = false }
    }
}