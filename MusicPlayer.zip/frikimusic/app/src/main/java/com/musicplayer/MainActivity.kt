package com.musicplayer

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.*
import android.provider.MediaStore
import android.widget.*
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var tvCurrentSong: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var seekBar: SeekBar
    private lateinit var miniPlayer: View
    private lateinit var btnTabAll: TextView
    private lateinit var btnTabStreaming: TextView
    private lateinit var imgMiniThumb: ImageView

    private val allSongs = ArrayList<Song>()
    private val streamingSongs = ArrayList<Song>()
    private var currentList = ArrayList<Song>()
    private var currentTab = 0

    private var musicService: MusicService? = null
    private var isBound = false
    private val handler = Handler(Looper.getMainLooper())
    private val PREFS_NAME = "frikimusic_streaming"
    private val STREAMING_KEY = "streaming_songs"

    private val streamReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val title    = intent.getStringExtra("title")   ?: return
            val artist   = intent.getStringExtra("artist")  ?: "YouTube"
            val videoId  = intent.getStringExtra("videoId") ?: return
            val duration = intent.getLongExtra("duration", 0L)
            val song = Song(title=title, artist=artist, path="", duration=duration, isStreaming=true, videoId=videoId)
            streamingSongs.removeAll { it.videoId == videoId }
            streamingSongs.add(0, song)
            saveStreamingSongs()
            if (currentTab == 1) {
                currentList = streamingSongs
                listView.adapter = SongAdapter(this@MainActivity, currentList)
                tvStatus.text = "${streamingSongs.size} en streaming"
            }
            musicService?.setSongList(arrayListOf(song))
            musicService?.playSongAt(0)
            updateMini()
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
        }
    }

    private val songAddedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            handler.postDelayed({ loadSongs() }, 1500)
        }
    }
    private val songChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            // Canción cambió automáticamente (auto-next) — actualizar mini player
            handler.post { updateMini() }
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
            musicService!!.setSongList(currentList)
        }
        override fun onServiceDisconnected(name: ComponentName) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView       = findViewById(R.id.listView)
        tvCurrentSong  = findViewById(R.id.tvCurrentSong)
        tvStatus       = findViewById(R.id.tvStatus)
        btnPlayPause   = findViewById(R.id.btnPlayPause)
        btnPrev        = findViewById(R.id.btnPrev)
        btnNext        = findViewById(R.id.btnNext)
        seekBar        = findViewById(R.id.seekBar)
        miniPlayer     = findViewById(R.id.miniPlayer)
        btnTabAll      = findViewById(R.id.btnTabAll)
        btnTabStreaming = findViewById(R.id.btnTabMeta)
        imgMiniThumb   = findViewById(R.id.imgMiniThumb)

        PlaylistManager.load(this)

        findViewById<ImageButton>(R.id.btnOpenDownload).setOnClickListener {
            startActivity(Intent(this, DownloadActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnOpenPlaylists).setOnClickListener {
            startActivity(Intent(this, PlaylistsActivity::class.java))
        }

        registerReceiver(streamReceiver,    IntentFilter("com.musicplayer.PLAY_STREAM"), Context.RECEIVER_NOT_EXPORTED)
        registerReceiver(songAddedReceiver, IntentFilter("com.musicplayer.SONG_ADDED"),  Context.RECEIVER_NOT_EXPORTED)
        registerReceiver(songChangedReceiver, IntentFilter("com.musicplayer.SONG_CHANGED"), Context.RECEIVER_NOT_EXPORTED)

        loadStreamingSongs()
        silentStreamCheck()
        checkPermissions()

        btnTabAll.setOnClickListener      { switchTab(0) }
        btnTabStreaming.setOnClickListener { switchTab(1) }

        btnPlayPause.setOnClickListener {
            val svc = musicService ?: return@setOnClickListener
            if (svc.isPlaying()) { svc.pause(); btnPlayPause.setImageResource(android.R.drawable.ic_media_play) }
            else { svc.play(); btnPlayPause.setImageResource(android.R.drawable.ic_media_pause) }
        }
        btnNext.setOnClickListener { musicService?.next(); updateMini() }
        btnPrev.setOnClickListener { musicService?.previous(); updateMini() }

        miniPlayer.setOnClickListener {
            if (musicService?.getCurrentSong() != null)
                startActivity(Intent(this, PlayerActivity::class.java))
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            musicService?.setSongList(currentList)
            musicService?.playSongAt(position)
            updateMini()
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
            startActivity(Intent(this, PlayerActivity::class.java))
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) musicService?.seekTo(p) }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        startSeekUpdater()
    }


    /** Escaneo silencioso al arrancar — si más de 3 streams fallan, limpia todo */
    private fun silentStreamCheck() {
        if (streamingSongs.isEmpty()) return
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        // Solo correr UNA VEZ por versión de la lista (guardamos un hash del tamaño+primer videoId)
        val checkKey = "stream_checked_${streamingSongs.size}_${streamingSongs.firstOrNull()?.videoId}"
        if (prefs.getBoolean(checkKey, false)) return
        prefs.edit().putBoolean(checkKey, true).apply()

        val toCheck = streamingSongs.toList()
        Thread {
            var failed = 0
            for (song in toCheck) {
                if (failed > 3) break
                try {
                    val body = org.json.JSONObject().apply {
                        put("url", "https://www.youtube.com/watch?v=${song.videoId}")
                        put("quality", "128")
                        put("apikey", "friki_ebddef50f2754a0182a51d781006fc4c")
                    }.toString()
                    val conn = java.net.URL("http://64.20.54.50:30325/api/ytmp3")
                        .openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.doOutput = true
                    conn.connectTimeout = 8000
                    conn.readTimeout = 15000
                    conn.outputStream.write(body.toByteArray())
                    val resp = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
                    conn.disconnect()
                    val ok = resp.optBoolean("success") && resp.has("dl")
                    if (!ok) failed++
                } catch (e: Exception) {
                    failed++
                }
            }

            if (failed > 3) {
                handler.post {
                    streamingSongs.clear()
                    saveStreamingSongs()
                    if (currentTab == 1) {
                        currentList = streamingSongs
                        listView.adapter = SongAdapter(this, currentList)
                        tvStatus.text = "0 en streaming"
                    }
                }
            }
        }.start()
    }
    private fun saveStreamingSongs() {
        val arr = JSONArray()
        for (s in streamingSongs) arr.put(JSONObject().apply {
            put("title", s.title); put("artist", s.artist)
            put("path", s.path); put("duration", s.duration); put("videoId", s.videoId)
        })
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(STREAMING_KEY, arr.toString()).apply()
    }

    private fun loadStreamingSongs() {
        val json = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(STREAMING_KEY, null) ?: return
        try {
            val arr = JSONArray(json); streamingSongs.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                streamingSongs.add(Song(o.getString("title"), o.getString("artist"), o.getString("path"), o.getLong("duration"), true, o.getString("videoId")))
            }
        } catch (e: Exception) { }
    }

    private fun switchTab(tab: Int) {
        currentTab = tab
        if (tab == 0) {
            currentList = allSongs
            btnTabAll.setTextColor(0xFF000000.toInt()); btnTabAll.setBackgroundResource(R.drawable.bg_pill_accent)
            btnTabStreaming.setTextColor(0xFF666666.toInt()); btnTabStreaming.setBackgroundResource(android.R.color.transparent)
            tvStatus.text = "${allSongs.size} canciones"
        } else {
            currentList = streamingSongs
            btnTabStreaming.setTextColor(0xFF000000.toInt()); btnTabStreaming.setBackgroundResource(R.drawable.bg_pill_accent)
            btnTabAll.setTextColor(0xFF666666.toInt()); btnTabAll.setBackgroundResource(android.R.color.transparent)
            tvStatus.text = "${streamingSongs.size} en streaming"
        }
        listView.adapter = SongAdapter(this, currentList)
        musicService?.setSongList(currentList)
    }

    private fun checkPermissions() {
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        else { loadSongs(); startMusicService() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 1 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) { loadSongs(); startMusicService() }
        else tvStatus.text = "Permiso denegado"
    }

    fun loadSongs() {
        allSongs.clear()
        val cursor: Cursor? = contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DURATION),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC"
        )
        cursor?.use { while (it.moveToNext()) allSongs.add(Song(it.getString(0), it.getString(1), it.getString(2), it.getLong(3))) }
        currentList = if (currentTab == 0) allSongs else streamingSongs
        listView.adapter = SongAdapter(this, currentList)
        tvStatus.text = if (currentTab == 0) "${allSongs.size} canciones" else "${streamingSongs.size} en streaming"
        musicService?.setSongList(currentList)
    }

    private fun startMusicService() {
        val i = Intent(this, MusicService::class.java)
        startService(i); bindService(i, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun updateMini() {
        val song = musicService?.getCurrentSong() ?: return
        tvCurrentSong.text = song.getTitleDisplay()
        seekBar.max = if (song.duration > 0) song.duration.toInt() else 100
        Thread { val art = song.getAlbumArt(); runOnUiThread { if (art != null) { imgMiniThumb.setImageBitmap(art); imgMiniThumb.scaleType = ImageView.ScaleType.CENTER_CROP } else imgMiniThumb.setImageResource(android.R.drawable.ic_media_play) } }.start()
    }

    private fun startSeekUpdater() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isBound && musicService?.isPlaying() == true) {
                    val dur = musicService!!.getDuration()
                    if (dur > 0) seekBar.max = dur
                    seekBar.progress = musicService!!.getCurrentPosition()
                    updateMini()
                }
                handler.postDelayed(this, 500)
            }
        }, 500)
    }

    override fun onResume() { super.onResume(); PlaylistManager.load(this) }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(streamReceiver); unregisterReceiver(songAddedReceiver); unregisterReceiver(songChangedReceiver)
        if (isBound) { unbindService(serviceConnection); isBound = false }
        handler.removeCallbacksAndMessages(null)
    }
}