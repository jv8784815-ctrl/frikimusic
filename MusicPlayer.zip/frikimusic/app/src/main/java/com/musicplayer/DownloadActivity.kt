package com.musicplayer

import android.content.Intent
import android.graphics.*
import android.media.MediaScannerConnection
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class DownloadActivity : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var btnSearch: ImageButton
    private lateinit var progressSearch: ProgressBar
    private lateinit var tvSearchStatus: TextView
    private lateinit var resultsContainer: LinearLayout
    private lateinit var scrollResults: ScrollView
    private lateinit var downloadStatusContainer: LinearLayout
    private lateinit var tvDownloadTitle: TextView
    private lateinit var progressDownload: ProgressBar
    private lateinit var tvDownloadStatus: TextView
    private lateinit var emptyState: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val VERCEL_API = "https://yt-downloader-by-josexo-and-abejitadiceiwiwiwi.vercel.app"

    data class VideoResult(val title: String, val author: String, val url: String, val videoId: String)
    data class ArtistResult(val name: String, val imageUrl: String, val subscribers: String, val browseId: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_download)

        etSearch                = findViewById(R.id.etSearch)
        btnSearch               = findViewById(R.id.btnSearch)
        progressSearch          = findViewById(R.id.progressSearch)
        tvSearchStatus          = findViewById(R.id.tvSearchStatus)
        resultsContainer        = findViewById(R.id.resultsContainer)
        scrollResults           = findViewById(R.id.scrollResults)
        downloadStatusContainer = findViewById(R.id.downloadStatusContainer)
        tvDownloadTitle         = findViewById(R.id.tvDownloadTitle)
        progressDownload        = findViewById(R.id.progressDownload)
        tvDownloadStatus        = findViewById(R.id.tvDownloadStatus)
        emptyState              = findViewById(R.id.emptyState)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        btnSearch.setOnClickListener { buscar() }
        etSearch.setOnEditorActionListener { _, _, _ -> buscar(); true }
    }

    private fun buscar() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return

        progressSearch.visibility = View.VISIBLE
        btnSearch.isEnabled = false
        tvSearchStatus.text = "Buscando..."
        tvSearchStatus.visibility = View.VISIBLE
        resultsContainer.removeAllViews()
        scrollResults.visibility = View.GONE
        emptyState.visibility = View.GONE

        Thread {
            var artist: ArtistResult? = null
            var videos: List<VideoResult> = emptyList()

            // Buscar en YouTube Music (artista) y YouTube (videos) en paralelo
            val t1 = Thread { try { artist = searchYTMusicArtist(q) } catch (e: Exception) {} }
            val t2 = Thread { try { videos = searchVideos(q) } catch (e: Exception) {} }
            t1.start(); t2.start()
            t1.join(); t2.join()

            handler.post {
                progressSearch.visibility = View.GONE
                btnSearch.isEnabled = true
                resultsContainer.removeAllViews()

                if (artist == null && videos.isEmpty()) {
                    tvSearchStatus.text = "Sin resultados para \"$q\""
                    emptyState.visibility = View.VISIBLE
                    return@post
                }

                tvSearchStatus.visibility = View.GONE

                // ── Top Result: artista de YouTube Music ──
                if (artist != null) {
                    addArtistCard(artist!!)
                    resultsContainer.addView(TextView(this).apply {
                        text = "Canciones"
                        setTextColor(Color.WHITE)
                        textSize = 15f
                        setTypeface(null, Typeface.BOLD)
                        setPadding(dp(16), dp(14), dp(16), dp(6))
                    })
                }

                mostrarResultados(videos)
                scrollResults.visibility = View.VISIBLE
            }
        }.start()
    }

    /** Busca artista en YouTube Music InnerTube API — igual que OpenTune */
    private fun searchYTMusicArtist(query: String): ArtistResult? {
        val body = JSONObject().apply {
            put("query", query)
            put("params", "EgWKAQIgAWoKEAMQBBAJEAoQBQ%3D%3D") // filtro: artistas
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", "WEB_REMIX")
                    put("clientVersion", "1.20231219.01.00")
                    put("hl", "es")
                })
            })
        }.toString()

        val conn = URL("https://music.youtube.com/youtubei/v1/search?prettyPrint=false")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.setRequestProperty("Referer", "https://music.youtube.com/")
        conn.setRequestProperty("Origin", "https://music.youtube.com")
        conn.doOutput = true
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.outputStream.write(body.toByteArray())

        val resp = JSONObject(conn.inputStream.bufferedReader().readText())
        conn.disconnect()

        // Parsear la respuesta de YouTube Music
        val contents = resp
            .optJSONObject("contents")
            ?.optJSONObject("tabbedSearchResultsRenderer")
            ?.optJSONArray("tabs")?.optJSONObject(0)
            ?.optJSONObject("tabRenderer")
            ?.optJSONObject("content")
            ?.optJSONObject("sectionListRenderer")
            ?.optJSONArray("contents")

        if (contents != null) {
            for (i in 0 until contents.length()) {
                val section = contents.optJSONObject(i) ?: continue
                val items = section.optJSONObject("musicShelfRenderer")
                    ?.optJSONArray("contents") ?: continue
                for (j in 0 until items.length()) {
                    val item = items.optJSONObject(j)
                        ?.optJSONObject("musicResponsiveListItemRenderer") ?: continue

                    // Verificar que es artista
                    val flexCols = item.optJSONArray("flexColumns") ?: continue
                    val subtitle = flexCols.optJSONObject(1)
                        ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.optJSONObject("text")
                        ?.optJSONArray("runs")
                        ?.optJSONObject(0)
                        ?.optString("text") ?: ""

                    if (!subtitle.lowercase().contains("artist") &&
                        !subtitle.lowercase().contains("artista")) continue

                    val name = flexCols.optJSONObject(0)
                        ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.optJSONObject("text")
                        ?.optJSONArray("runs")
                        ?.optJSONObject(0)
                        ?.optString("text") ?: continue

                    // Imagen
                    val thumbnails = item.optJSONObject("thumbnail")
                        ?.optJSONObject("musicThumbnailRenderer")
                        ?.optJSONObject("thumbnail")
                        ?.optJSONArray("thumbnails")
                    val imageUrl = thumbnails?.optJSONObject(thumbnails.length() - 1)
                        ?.optString("url") ?: ""

                    // Subscribers (si están disponibles)
                    val subs = flexCols.optJSONObject(1)
                        ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.optJSONObject("text")
                        ?.optJSONArray("runs")
                        ?.let { runs ->
                            (0 until runs.length()).map { runs.getJSONObject(it).optString("text") }
                                .filter { it.contains("sub", ignoreCase = true) || it.contains("K") || it.contains("M") }
                                .firstOrNull()
                        } ?: subtitle

                    // browseId para navegar al artista
                    val browseId = item.optJSONObject("navigationEndpoint")
                        ?.optJSONObject("browseEndpoint")
                        ?.optString("browseId") ?: ""

                    return ArtistResult(name, imageUrl, subs, browseId)
                }
            }
        }
        return null
    }

    /** Tarjeta Top Result estilo OpenTune */
    private fun addArtistCard(artist: ArtistResult) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#111111"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(4) }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@DownloadActivity, ArtistActivity::class.java).apply {
                    putExtra("artist_name", artist.name)
                })
            }
        }

        val tvLabel = TextView(this).apply {
            text = "Top result"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(16), dp(14), dp(16), dp(8))
        }
        card.addView(tvLabel)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), dp(16))
        }

        val img = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(70), dp(70)).also { it.marginEnd = dp(16) }
            setBackgroundColor(Color.parseColor("#222222"))
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        row.addView(img)

        // Cargar imagen circular
        if (artist.imageUrl.isNotEmpty()) {
            Thread {
                try {
                    val conn = URL(artist.imageUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 6000; conn.readTimeout = 6000
                    val bmp = BitmapFactory.decodeStream(conn.inputStream)
                    conn.disconnect()
                    if (bmp != null) handler.post { img.setImageBitmap(toCircle(bmp)) }
                } catch (e: Exception) {}
            }.start()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(TextView(this).apply {
            text = artist.name
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = "Artista"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, dp(3), 0, 0)
        })
        if (artist.subscribers.isNotEmpty() && artist.subscribers != "Artista") {
            col.addView(TextView(this).apply {
                text = artist.subscribers
                setTextColor(Color.parseColor("#666666"))
                textSize = 11f
                setPadding(0, dp(2), 0, 0)
            })
        }
        row.addView(col)
        card.addView(row)
        resultsContainer.addView(card)
    }

    private fun toCircle(bmp: Bitmap): Bitmap {
        val size = minOf(bmp.width, bmp.height)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(bmp, ((bmp.width - size) / 2).toFloat(), ((bmp.height - size) / 2).toFloat(), paint)
        return out
    }

    private fun searchVideos(query: String): List<VideoResult> {
        if (query.contains("youtu.be/") || query.contains("youtube.com/")) {
            val videoId = extractVideoId(query) ?: return emptyList()
            return try {
                val conn = URL("https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$videoId&format=json")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                conn.disconnect()
                listOf(VideoResult(json.optString("title", "Video"), json.optString("author_name", "YouTube"),
                    "https://www.youtube.com/watch?v=$videoId", videoId))
            } catch (e: Exception) {
                listOf(VideoResult("Video de YouTube", "YouTube", "https://www.youtube.com/watch?v=$videoId", videoId))
            }
        }

        val body = JSONObject().apply {
            put("query", query)
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", "WEB"); put("clientVersion", "2.20231219.04.00"); put("hl", "es")
                })
            })
        }.toString()

        val conn = URL("https://www.youtube.com/youtubei/v1/search?prettyPrint=false").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
        conn.doOutput = true; conn.connectTimeout = 12000; conn.readTimeout = 12000
        conn.outputStream.write(body.toByteArray())

        val resp = JSONObject(conn.inputStream.bufferedReader().readText())
        conn.disconnect()

        val results = mutableListOf<VideoResult>()
        val contents = resp.optJSONObject("contents")
            ?.optJSONObject("twoColumnSearchResultsRenderer")
            ?.optJSONObject("primaryContents")
            ?.optJSONObject("sectionListRenderer")
            ?.optJSONArray("contents")

        if (contents != null) {
            for (i in 0 until contents.length()) {
                val section = contents.optJSONObject(i)?.optJSONObject("itemSectionRenderer")
                    ?.optJSONArray("contents") ?: continue
                for (j in 0 until section.length()) {
                    val vr = section.optJSONObject(j)?.optJSONObject("videoRenderer") ?: continue
                    val id = vr.optString("videoId").takeIf { it.length == 11 } ?: continue
                    val title = vr.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: continue
                    val channel = vr.optJSONObject("ownerText")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "YouTube"
                    results.add(VideoResult(title, channel, "https://www.youtube.com/watch?v=$id", id))
                    if (results.size >= 8) break
                }
                if (results.size >= 8) break
            }
        }
        return results
    }

    private fun extractVideoId(url: String): String? {
        listOf(
            Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Regex("youtube\\.com/watch\\?v=([a-zA-Z0-9_-]{11})"),
            Regex("youtube\\.com/shorts/([a-zA-Z0-9_-]{11})")
        ).forEach { p -> p.find(url)?.let { return it.groupValues[1] } }
        return null
    }

    private fun mostrarResultados(results: List<VideoResult>) {
        for (video in results) {
            val card = layoutInflater.inflate(R.layout.item_video_result, resultsContainer, false)
            card.findViewById<TextView>(R.id.tvVideoTitle).text = video.title
            val tvChannel = card.findViewById<TextView>(R.id.tvVideoChannel)
            tvChannel.text = video.author
            tvChannel.setTextColor(Color.parseColor("#FF3B30"))
            tvChannel.setOnClickListener {
                startActivity(Intent(this, ArtistActivity::class.java).apply {
                    putExtra("artist_name", video.author)
                })
            }
            loadThumbnail(card.findViewById(R.id.ivVideoThumb), video.videoId)
            card.findViewById<LinearLayout>(R.id.btnStreamRow).setOnClickListener { startStreaming(video) }
            card.findViewById<LinearLayout>(R.id.btnMp3Row).setOnClickListener { startDownload(video) }
            resultsContainer.addView(card)
        }
    }

    private fun loadThumbnail(iv: ImageView, videoId: String) {
        Thread {
            try {
                val conn = URL("https://img.youtube.com/vi/$videoId/mqdefault.jpg").openConnection() as HttpURLConnection
                conn.connectTimeout = 5000; conn.readTimeout = 5000
                val bmp = BitmapFactory.decodeStream(conn.inputStream)
                conn.disconnect()
                handler.post { iv.setImageBitmap(bmp) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun startStreaming(video: VideoResult) {
        downloadStatusContainer.visibility = View.VISIBLE
        tvDownloadTitle.text = video.title
        tvDownloadStatus.text = "Conectando..."
        progressDownload.visibility = View.VISIBLE
        progressDownload.isIndeterminate = true
        sendBroadcast(Intent("com.musicplayer.PLAY_STREAM").apply {
            putExtra("title", video.title); putExtra("artist", video.author)
            putExtra("taskId", ""); putExtra("videoId", video.videoId); putExtra("duration", 0L)
        })
        handler.post {
            progressDownload.isIndeterminate = false; progressDownload.progress = 100
            tvDownloadStatus.text = "Reproduciendo..."
            Toast.makeText(this, video.title.take(30), Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDownload(video: VideoResult) {
        downloadStatusContainer.visibility = View.VISIBLE
        tvDownloadTitle.text = video.title
        tvDownloadStatus.text = "Obteniendo enlace..."
        progressDownload.visibility = View.VISIBLE
        progressDownload.isIndeterminate = true
        Thread {
            try {
                val body = JSONObject().apply { put("url", video.url); put("format", "mp3") }.toString()
                val conn = URL("$VERCEL_API/api/app-download").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true; conn.connectTimeout = 30000; conn.readTimeout = 120000
                conn.outputStream.write(body.toByteArray())
                val resp = JSONObject(conn.inputStream.bufferedReader().readText()); conn.disconnect()
                val relativeUrl = resp.optString("url").takeIf { it.isNotEmpty() } ?: throw Exception("No URL")
                val dlUrl = "$VERCEL_API$relativeUrl"
                val title = resp.optString("title").takeIf { it.isNotEmpty() } ?: video.title
                handler.post { tvDownloadStatus.text = "Descargando..." }
                val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                val file = File(dir, "${title.replace(Regex("[<>:\"/\\\\|?*]"), "").take(50)}.mp3")
                val dlConn = URL(dlUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60000; dlConn.readTimeout = 180000
                val total = dlConn.contentLength.toLong()
                dlConn.inputStream.use { i -> FileOutputStream(file).use { o ->
                    val buf = ByteArray(8192); var dl = 0L; var n: Int
                    while (i.read(buf).also { n = it } != -1) { o.write(buf, 0, n); dl += n
                        if (total > 0) handler.post { progressDownload.isIndeterminate = false; progressDownload.progress = (dl * 100 / total).toInt(); tvDownloadStatus.text = "Descargando... ${(dl*100/total).toInt()}%" }
                    }
                }}; dlConn.disconnect()
                MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), arrayOf("audio/mpeg"), null)
                sendBroadcast(Intent("com.musicplayer.SONG_ADDED"))
                handler.post {
                    progressDownload.isIndeterminate = false; progressDownload.progress = 100
                    tvDownloadStatus.text = "Listo — ${String.format("%.1f", file.length()/1024f/1024f)} MB en Downloads"
                    Toast.makeText(this, "${title.take(30)} descargado", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                handler.post { tvDownloadStatus.text = "Error: ${e.message?.take(80)}"; progressDownload.visibility = View.GONE }
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}