package com.musicplayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class MusicWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_PLAY  = "com.musicplayer.WIDGET_PLAY"
        const val ACTION_NEXT  = "com.musicplayer.WIDGET_NEXT"
        const val ACTION_PREV  = "com.musicplayer.WIDGET_PREV"

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int, song: Song?, isPlaying: Boolean) {
            val views = RemoteViews(context.packageName, R.layout.widget_player)

            // Title & artist
            views.setTextViewText(R.id.widget_title,  song?.getTitleDisplay()  ?: "Sin música")
            views.setTextViewText(R.id.widget_artist, song?.getArtistDisplay() ?: "FrikiMusic")

            // Play/pause icon
            val playIcon = if (isPlaying) android.R.drawable.ic_media_pause
                           else android.R.drawable.ic_media_play
            views.setImageViewResource(R.id.widget_btn_play, playIcon)

            // Album art
            val art = song?.getAlbumArt()
            if (art != null) views.setImageViewBitmap(R.id.widget_album_art, art)
            else views.setImageViewResource(R.id.widget_album_art, android.R.drawable.ic_media_play)

            // Button intents
            views.setOnClickPendingIntent(R.id.widget_btn_play, pending(context, ACTION_PLAY))
            views.setOnClickPendingIntent(R.id.widget_btn_next, pending(context, ACTION_NEXT))
            views.setOnClickPendingIntent(R.id.widget_btn_prev, pending(context, ACTION_PREV))

            // Open app on tap
            val openApp = Intent(context, MainActivity::class.java)
            views.setOnClickPendingIntent(R.id.widget_title,
                PendingIntent.getActivity(context, 0, openApp,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            manager.updateAppWidget(id, views)
        }

        private fun pending(context: Context, action: String): PendingIntent {
            val intent = Intent(context, MusicWidget::class.java).apply { this.action = action }
            return PendingIntent.getBroadcast(context, action.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val serviceIntent = Intent(context, MusicService::class.java).apply {
            action = when (intent.action) {
                ACTION_PLAY -> MusicService.ACTION_PLAY
                ACTION_NEXT -> MusicService.ACTION_NEXT
                ACTION_PREV -> MusicService.ACTION_PREV
                else        -> return
            }
        }
        context.startService(serviceIntent)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) updateWidget(context, manager, id, null, false)
    }
}