package com.musicplayer

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PlaylistsActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlists)

        listView = findViewById(R.id.listViewPlaylists)
        tvEmpty  = findViewById(R.id.tvEmptyPlaylists)

        PlaylistManager.load(this)

        findViewById<ImageButton>(R.id.btnBackPlaylists).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnNewPlaylist).setOnClickListener { showCreateDialog() }

        listView.setOnItemClickListener { _, _, position, _ ->
            val pl = PlaylistManager.getAll().getOrNull(position) ?: return@setOnItemClickListener
            startActivity(Intent(this, PlaylistActivity::class.java).putExtra("playlist_id", pl.id))
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            val pl = PlaylistManager.getAll().getOrNull(position) ?: return@setOnItemLongClickListener true
            AlertDialog.Builder(this)
                .setTitle("Eliminar \"${pl.name}\"")
                .setMessage("No se borrarán los archivos de audio.")
                .setPositiveButton("Eliminar") { _, _ -> PlaylistManager.delete(this, pl.id); refreshUI() }
                .setNegativeButton("Cancelar", null).show()
            true
        }

        refreshUI()
    }

    private fun showCreateDialog() {
        val et = EditText(this).apply { hint = "Nombre de la playlist"; setPadding(48, 28, 48, 28) }
        AlertDialog.Builder(this)
            .setTitle("Nueva playlist")
            .setView(et)
            .setPositiveButton("Crear") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) Toast.makeText(this, "Escribe un nombre", Toast.LENGTH_SHORT).show()
                else { PlaylistManager.create(this, name); refreshUI() }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun refreshUI() {
        val all = PlaylistManager.getAll()
        listView.adapter = PlaylistAdapter(this, all)
        tvEmpty.visibility  = if (all.isEmpty()) View.VISIBLE else View.GONE
        listView.visibility = if (all.isEmpty()) View.GONE   else View.VISIBLE
    }

    override fun onResume() { super.onResume(); PlaylistManager.load(this); refreshUI() }
}