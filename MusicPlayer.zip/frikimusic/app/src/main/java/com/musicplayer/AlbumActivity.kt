package com.musicplayer

import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.*
import java.net.*

class AlbumActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    data class AlbumTrack(val index: Int, val title: String, val videoId: String, val duration: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val browseId   = intent.getStringExtra("browse_id")   ?: run { finish(); return }
        val albumTitle = intent.getStringExtra("album_title")  ?: ""
        val albumArt   = intent.getStringExtra("album_art")    ?: ""
        val artistName = intent.getStringExtra("artist_name")  ?: ""
        val albumYear  = intent.getStringExtra("album_year")   ?: ""

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        scroll.addView(root)
        setContentView(scroll)

        // ── Header con portada ──
        val headerFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300))
        }
        val imgCover = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.parseColor("#1A1A1A"))
        }
        headerFrame.addView(imgCover)

        val gradient = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#44000000"), Color.parseColor("#CC000000"), Color.BLACK)
            )
        }
        headerFrame.addView(gradient)

        val btnBack = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.parseColor("#44000000"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40)).apply {
                topMargin = dp(24); leftMargin = dp(16)
            }
        }
        btnBack.setOnClickListener { finish() }
        headerFrame.addView(btnBack)

        root.addView(headerFrame)

        // ── Info del álbum ──
        val infoLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }

        val tvTitle = TextView(this).apply {
            text = albumTitle
            setTextColor(Color.WHITE)
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        }
        infoLayout.addView(tvTitle)

        val tvArtist = TextView(this).apply {
            text = artistName
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 14f
            setPadding(0, dp(4), 0, 0)
        }
        infoLayout.addView(tvArtist)

        val tvMeta = TextView(this).apply {
            text = albumYear
            setTextColor(Color.parseColor("#666666"))
            textSize = 12f
            setPadding(0, dp(4), 0, 0)
        }
        infoLayout.addView(tvMeta)

        root.addView(infoLayout)

        // ── Botones Play y Shuffle ──
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(8), dp(20), dp(16))
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnPlay = TextView(this).apply {
            text = "▶  Reproducir"
            setTextColor(Color.BLACK)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(20), dp(14), dp(20), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(10)
            }
        }
        btnRow.addView(btnPlay)

        val btnShuffle = TextView(this).apply {
            text = "⇌  Aleatorio"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#222222"))
            setPadding(dp(20), dp(14), dp(20), dp(14))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnRow.addView(btnShuffle)

        root.addView(btnRow)

        // ── Divisor ──
        root.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
            setBackgroundColor(Color.parseColor("#222222"))
        })

        // ── Lista de canciones ──
        val tvTracksLabel = TextView(this).apply {
            text = "Canciones"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        root.addView(tvTracksLabel)

        val tracksContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tvLoading = TextView(this).apply {
            text = "Cargando canciones..."
            setTextColor(Color.parseColor("#555555"))
            textSize = 13f
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        tracksContainer.addView(tvLoading)
        root.addView(tracksContainer)

        // Espacio final
        root.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40))
        })

        // ── Cargar portada ──
        if (albumArt.isNotEmpty()) {
            loadBitmap(albumArt) { imgCover.setImageBitmap(it) }
        }

        // ── Cargar canciones desde Innertube ──
        var trackList = listOf<AlbumTrack>()

        Thread {
            fetchAlbumTracks(browseId) { tracks, songCount, totalDuration ->
                trackList = tracks
                handler.post {
                    // Actualizar meta con datos reales
                    val metaText = buildString {
                        if (albumYear.isNotEmpty()) append(albumYear)
                        if (songCount > 0) {
                            if (isNotEmpty()) append(" · ")
                            append("$songCount canciones")
                        }
                        if (totalDuration.isNotEmpty()) {
                            if (isNotEmpty()) append(" · ")
                            append(totalDuration)
                        }
                    }
                    tvMeta.text = metaText

                    tracksContainer.removeAllViews()
                    if (tracks.isEmpty()) {
                        tracksContainer.addView(TextView(this).apply {
                            text = "Sin canciones disponibles"
                            setTextColor(Color.parseColor("#555555"))
                            setPadding(dp(20), dp(8), dp(20), dp(8))
                        })
                    } else {
                        tracks.forEach { track ->
                            tracksContainer.addView(buildTrackRow(track, artistName) {
                                playFrom(tracks, track.index - 1, artistName, false)
                            })
                        }
                    }

                    // Play: reproduce todas desde la primera
                    btnPlay.setOnClickListener {
                        if (trackList.isNotEmpty()) {
                            playFrom(trackList, 0, artistName, false)
                            Toast.makeText(this, "▶ Reproduciendo álbum", Toast.LENGTH_SHORT).show()
                        }
                    }

                    // Shuffle: reproduce en orden aleatorio
                    btnShuffle.setOnClickListener {
                        if (trackList.isNotEmpty()) {
                            playFrom(trackList, 0, artistName, true)
                            Toast.makeText(this, "⇌ Modo aleatorio", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }.start()
    }

    private fun playFrom(tracks: List<AlbumTrack>, startIndex: Int, artistName: String, shuffle: Boolean) {
        val list = if (shuffle) tracks.shuffled() else tracks
        val startTrack = list[startIndex]
        sendBroadcast(Intent("com.musicplayer.PLAY_STREAM").apply {
            putExtra("title", startTrack.title)
            putExtra("artist", artistName)
            putExtra("videoId", startTrack.videoId)
            putExtra("duration", 0L)
        })
    }

    private fun fetchAlbumTracks(
        browseId: String,
        cb: (tracks: List<AlbumTrack>, songCount: Int, totalDuration: String) -> Unit
    ) {
        try {
            val body = JSONObject().apply {
                put("browseId", browseId)
                put("context", JSONObject().apply {
                    put("client", JSONObject().apply {
                        put("clientName", "WEB_REMIX")
                        put("clientVersion", "1.20231219.01.00")
                        put("hl", "es")
                    })
                })
            }.toString()

            val conn = URL("https://music.youtube.com/youtubei/v1/browse?prettyPrint=false")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.setRequestProperty("Referer", "https://music.youtube.com/")
            conn.doOutput = true
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.outputStream.write(body.toByteArray())

            val resp = JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()

            val tracks = mutableListOf<AlbumTrack>()

            // Navegar al contenido del álbum
            val contents = resp.optJSONObject("contents")
                ?.optJSONObject("singleColumnBrowseResultsRenderer")
                ?.optJSONArray("tabs")?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")?.optJSONArray("contents")
                ?.optJSONObject(0)
                ?.optJSONObject("musicShelfRenderer")
                ?.optJSONArray("contents")

            if (contents != null) {
                for (i in 0 until contents.length()) {
                    val item = contents.optJSONObject(i)
                        ?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                    val flex = item.optJSONArray("flexColumns") ?: continue

                    val title = flex.optJSONObject(0)
                        ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)
                        ?.optString("text") ?: continue

                    val dur = flex.optJSONObject(1)
                        ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.optJSONObject("text")?.optJSONArray("runs")
                        ?.let { runs ->
                            (0 until runs.length())
                                .map { runs.getJSONObject(it).optString("text") }
                                .find { it.contains(":") }
                        } ?: ""

                    val videoId = item.optJSONObject("overlay")
                        ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                        ?.optJSONObject("content")?.optJSONObject("musicPlayButtonRenderer")
                        ?.optJSONObject("playNavigationEndpoint")?.optJSONObject("watchEndpoint")
                        ?.optString("videoId")
                        ?: item.optJSONArray("flexColumns")
                            ?.optJSONObject(0)
                            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                            ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)
                            ?.optJSONObject("navigationEndpoint")?.optJSONObject("watchEndpoint")
                            ?.optString("videoId") ?: ""

                    if (videoId.isNotEmpty()) {
                        tracks.add(AlbumTrack(tracks.size + 1, title, videoId, dur))
                    }
                }
            }

            // Calcular duración total
            var totalSeconds = 0
            tracks.forEach { t ->
                val parts = t.duration.split(":")
                if (parts.size == 2) {
                    totalSeconds += (parts[0].toIntOrNull() ?: 0) * 60 + (parts[1].toIntOrNull() ?: 0)
                }
            }
            val totalMin = totalSeconds / 60
            val totalSec = totalSeconds % 60
            val totalStr = if (totalSeconds > 0) "$totalMin:${totalSec.toString().padStart(2, '0')}" else ""

            cb(tracks, tracks.size, totalStr)

        } catch (e: Exception) {
            handler.post {
                Toast.makeText(this, "Error: ${e.message?.take(60)}", Toast.LENGTH_LONG).show()
            }
            cb(emptyList(), 0, "")
        }
    }

    private fun buildTrackRow(track: AlbumTrack, artistName: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

        // Número
        row.addView(TextView(this).apply {
            text = "${track.index}"
            setTextColor(Color.parseColor("#555555"))
            textSize = 14f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(32), LinearLayout.LayoutParams.WRAP_CONTENT)
        })

        // Info
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(12)
            }
        }
        col.addView(TextView(this).apply {
            text = track.title
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = artistName
            setTextColor(Color.parseColor("#666666"))
            textSize = 12f
            setPadding(0, dp(2), 0, 0)
            maxLines = 1
        })
        row.addView(col)

        // Duración
        if (track.duration.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = track.duration
                setTextColor(Color.parseColor("#555555"))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(8) }
            })
        }

        row.setOnClickListener { onClick() }
        return row
    }

    private fun loadBitmap(url: String, cb: (Bitmap) -> Unit) {
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val bmp = BitmapFactory.decodeStream(conn.inputStream)
                conn.disconnect()
                if (bmp != null) handler.post { cb(bmp) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}