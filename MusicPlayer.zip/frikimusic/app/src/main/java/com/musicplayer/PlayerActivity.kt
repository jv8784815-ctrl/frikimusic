package com.musicplayer

import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class PlayerActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var imgAlbum: ImageView
    private lateinit var btnBack: ImageButton
    private lateinit var btnSaveOffline: Button
    private lateinit var btnShowLyrics: ImageButton

    private lateinit var lyricsOverlay: FrameLayout
    private lateinit var scrollLyrics: ScrollView
    private lateinit var tvLyrics: TextView
    private lateinit var btnCloseLyrics: Button
    private lateinit var btnToggleScroll: Button
    private lateinit var btnSearchLyrics: Button
    private lateinit var etLyricsSearch: EditText
    private lateinit var searchLyricsContainer: LinearLayout

    // ── LRC sincronizado ──
    private lateinit var lrcContainer: LinearLayout   // filas de letras
    private var lrcLines = listOf<LrcLine>()          // líneas parseadas
    private var lrcActive = false                     // true = modo LRC
    private var currentLrcIndex = -1                  // índea resaltada actualmente
    private var lrcSyncRunnable: Runnable? = null

    data class LrcLine(val timeMs: Long, val text: String)

    private var musicService: MusicService? = null
    private var isBound = false
    private val handler = Handler(Looper.getMainLooper())
    private val VERCEL_API = "https://yt-downloader-by-josexo-and-abejitadiceiwiwiwi.vercel.app"

    private var autoScrollEnabled = true
    private var autoScrollRunnable: Runnable? = null
    private var lyricsVisible = false

    private var durationReceiver: BroadcastReceiver? = null
    private var songChangedReceiver: BroadcastReceiver? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            musicService = (binder as MusicService.MusicBinder).getService()
            isBound = true
            updateUI()
        }
        override fun onServiceDisconnected(name: ComponentName) { isBound = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        tvTitle               = findViewById(R.id.tvPlayerTitle)
        tvArtist              = findViewById(R.id.tvPlayerArtist)
        btnPlayPause          = findViewById(R.id.btnPlayerPlayPause)
        btnPrev               = findViewById(R.id.btnPlayerPrev)
        btnNext               = findViewById(R.id.btnPlayerNext)
        seekBar               = findViewById(R.id.playerSeekBar)
        tvCurrentTime         = findViewById(R.id.tvCurrentTime)
        tvTotalTime           = findViewById(R.id.tvTotalTime)
        imgAlbum              = findViewById(R.id.imgAlbum)
        btnBack               = findViewById(R.id.btnBack)
        btnSaveOffline        = findViewById(R.id.btnSaveOffline)
        btnShowLyrics         = findViewById(R.id.btnShowLyrics)
        lyricsOverlay         = findViewById(R.id.lyricsOverlay)
        scrollLyrics          = findViewById(R.id.scrollLyrics)
        tvLyrics              = findViewById(R.id.tvLyrics)
        btnCloseLyrics        = findViewById(R.id.btnCloseLyrics)
        btnToggleScroll       = findViewById(R.id.btnToggleScroll)
        btnSearchLyrics       = findViewById(R.id.btnSearchLyrics)
        etLyricsSearch        = findViewById(R.id.etLyricsSearch)
        searchLyricsContainer = findViewById(R.id.searchLyricsContainer)

        // Contenedor de filas LRC (se agrega programáticamente dentro del ScrollView)
        lrcContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(100))
        }
        // Insertar lrcContainer como hijo del scrollLyrics si aún no tiene
        // (tvLyrics queda para el fallback de texto plano)

        bindService(Intent(this, MusicService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)

        durationReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (isDestroyed || isFinishing) return
                val dur = intent.getLongExtra("duration", 0L)
                if (dur > 0) applyDuration(dur.toInt())
            }
        }
        registerReceiver(durationReceiver, IntentFilter("com.musicplayer.DURATION_READY"), Context.RECEIVER_NOT_EXPORTED)

        songChangedReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (isDestroyed || isFinishing) return
                handler.post {
                    updateUI()
                    if (lyricsVisible) reloadLyrics()
                }
            }
        }
        registerReceiver(songChangedReceiver, IntentFilter("com.musicplayer.SONG_CHANGED"), Context.RECEIVER_NOT_EXPORTED)

        btnBack.setOnClickListener { if (lyricsVisible) hideLyrics() else finish() }
        btnShowLyrics.setOnClickListener { showLyrics() }
        btnCloseLyrics.setOnClickListener { hideLyrics() }

        btnPlayPause.setOnClickListener {
            val svc = musicService ?: return@setOnClickListener
            if (svc.isPlaying()) {
                svc.pause()
                btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
            } else {
                svc.play()
                btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
            }
        }

        btnNext.setOnClickListener { musicService?.next(); updateUI(); if (lyricsVisible) reloadLyrics() }
        btnPrev.setOnClickListener { musicService?.previous(); updateUI(); if (lyricsVisible) reloadLyrics() }

        btnSaveOffline.setOnClickListener {
            val song = musicService?.getCurrentSong()
            if (song != null && song.isStreaming) downloadSong(song)
        }

        btnToggleScroll.setOnClickListener {
            if (lrcActive) return@setOnClickListener   // en modo LRC el scroll es automático siempre
            autoScrollEnabled = !autoScrollEnabled
            if (autoScrollEnabled) { btnToggleScroll.text = "Pausar"; startAutoScroll() }
            else { btnToggleScroll.text = "Scroll"; stopAutoScroll() }
        }

        btnSearchLyrics.setOnClickListener {
            val q = etLyricsSearch.text.toString().trim()
            if (q.isNotEmpty()) buscarLetraManual(q)
        }
        etLyricsSearch.setOnEditorActionListener { _, _, _ ->
            val q = etLyricsSearch.text.toString().trim()
            if (q.isNotEmpty()) buscarLetraManual(q)
            true
        }

        scrollLyrics.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN && autoScrollEnabled && !lrcActive) {
                autoScrollEnabled = false
                btnToggleScroll.text = "Scroll"
                stopAutoScroll()
            }
            false
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    musicService?.seekTo(progress)
                    tvCurrentTime.text = formatTime(progress.toLong())
                    if (lrcActive) syncLrcToPosition(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        startSeekUpdater()
    }

    // ─────────────────────────── LRC ───────────────────────────

    /** Parsea texto LRC en lista de LrcLine ordenada por tiempo */
    private fun parseLrc(raw: String): List<LrcLine> {
        val regex = Regex("""\[(\d{2}):(\d{2})\.(\d{1,3})\](.*)""")
        return raw.lines()
            .mapNotNull { line ->
                regex.matchEntire(line.trim())?.let { m ->
                    val min  = m.groupValues[1].toLong()
                    val sec  = m.groupValues[2].toLong()
                    val ms   = m.groupValues[3].padEnd(3, '0').toLong()
                    val text = m.groupValues[4].trim()
                    LrcLine((min * 60 + sec) * 1000 + ms, text)
                }
            }
            .sortedBy { it.timeMs }
    }

    /** Muestra el LRC en el ScrollView como filas individuales */
    private fun showLrcLines() {
        // Reemplazar tvLyrics por lrcContainer dentro del scrollLyrics
        val parent = scrollLyrics
        parent.removeAllViews()
        lrcContainer.removeAllViews()

        // Crear una TextView por línea
        for ((_, text) in lrcLines) {
            val tv = TextView(this).apply {
                this.text = if (text.isEmpty()) " " else text
                textSize  = 18f
                setTextColor(Color.parseColor("#44FFFFFF"))   // gris translúcido = inactiva
                setTypeface(null, Typeface.BOLD)
                setPadding(0, dp(10), 0, dp(10))
                gravity = Gravity.CENTER
            }
            lrcContainer.addView(tv)
        }

        parent.addView(lrcContainer)
        currentLrcIndex = -1
        startLrcSync()
    }

    /** Loop que cada 100ms busca la línea activa y la resalta */
    private fun startLrcSync() {
        stopLrcSync()
        lrcSyncRunnable = object : Runnable {
            override fun run() {
                if (!lyricsVisible || isDestroyed || isFinishing) return
                val pos = musicService?.getCurrentPosition()?.toLong() ?: 0L
                syncLrcToPosition(pos)
                handler.postDelayed(this, 100)
            }
        }
        handler.post(lrcSyncRunnable!!)
    }

    private fun syncLrcToPosition(posMs: Long) {
        if (lrcLines.isEmpty()) return

        // Encontrar el índice de la última línea cuyo tiempo <= posición actual
        var idx = -1
        for (i in lrcLines.indices) {
            if (lrcLines[i].timeMs <= posMs) idx = i else break
        }

        if (idx == currentLrcIndex) return   // sin cambio
        currentLrcIndex = idx

        // Resaltar
        for (i in lrcLines.indices) {
            val tv = lrcContainer.getChildAt(i) as? TextView ?: continue
            when {
                i == idx -> {
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 20f
                    setTypeface(tv, Typeface.BOLD)
                }
                i < idx -> {
                    tv.setTextColor(Color.parseColor("#33FFFFFF"))
                    tv.textSize = 17f
                }
                else -> {
                    tv.setTextColor(Color.parseColor("#55FFFFFF"))
                    tv.textSize = 17f
                }
            }
        }

        // Scroll suave a la línea activa
        if (idx >= 0) {
            val tv = lrcContainer.getChildAt(idx) as? TextView ?: return
            val targetY = (tv.top + lrcContainer.paddingTop - scrollLyrics.height / 2 + tv.height / 2)
                .coerceAtLeast(0)
            scrollLyrics.smoothScrollTo(0, targetY)
        }
    }

    private fun setTypeface(tv: TextView, style: Int) { tv.setTypeface(null, style) }

    private fun stopLrcSync() {
        lrcSyncRunnable?.let { handler.removeCallbacks(it) }
        lrcSyncRunnable = null
    }

    // ─────────────────────────── Lyrics load ───────────────────────────

    private fun showLyrics() {
        lyricsVisible = true
        lyricsOverlay.visibility = View.VISIBLE
        autoScrollEnabled = true
        btnToggleScroll.text = "Pausar"
        reloadLyrics()
    }

    private fun hideLyrics() {
        lyricsVisible = false
        lyricsOverlay.visibility = View.GONE
        stopAutoScroll()
        stopLrcSync()
        lrcActive = false
    }

    private fun reloadLyrics() {
        val song = musicService?.getCurrentSong() ?: return
        val rawTitle = song.getTitleDisplay()
        val title  = if (rawTitle.contains(" - ")) rawTitle.substringAfter(" - ").trim() else rawTitle
        val artist = song.getArtistDisplay().takeIf { it.isNotEmpty() && it != "Artista desconocido" } ?: ""

        stopAutoScroll(); stopLrcSync()
        lrcActive = false; lrcLines = emptyList(); currentLrcIndex = -1

        // Restaurar tvLyrics en el scroll por si estaba lrcContainer
        scrollLyrics.removeAllViews()
        tvLyrics.text = "Buscando letra…"
        scrollLyrics.addView(tvLyrics)
        scrollLyrics.scrollTo(0, 0)
        etLyricsSearch.setText(title)
        searchLyricsContainer.visibility = View.VISIBLE

        Thread {
            // 1. Intentar LRC sincronizado desde lrclib.net
            val lrc = fetchLrcLib(title, artist)
            if (lrc != null && lrc.contains("[")) {
                val parsed = parseLrc(lrc)
                if (parsed.size >= 3) {
                    if (isDestroyed || isFinishing) return@Thread
                    handler.post {
                        if (isDestroyed || isFinishing) return@post
                        lrcLines  = parsed
                        lrcActive = true
                        btnToggleScroll.text = "Sync ✓"
                        showLrcLines()
                    }
                    return@Thread
                }
            }

            // 2. Fallback: letra plana de Vercel
            val plain = fetchLyricsVercel(title)
            if (isDestroyed || isFinishing) return@Thread
            handler.post {
                if (isDestroyed || isFinishing) return@post
                scrollLyrics.removeAllViews()
                scrollLyrics.addView(tvLyrics)
                if (plain != null) {
                    tvLyrics.text = plain
                    btnToggleScroll.text = "Pausar"
                    handler.postDelayed({ if (autoScrollEnabled) startAutoScroll() }, 800)
                } else {
                    tvLyrics.text = "No se encontró la letra de:\n\n\"$title\""
                    autoScrollEnabled = false
                    btnToggleScroll.text = "Scroll"
                }
            }
        }.start()
    }

    private fun buscarLetraManual(query: String) {
        stopAutoScroll(); stopLrcSync()
        lrcActive = false; lrcLines = emptyList(); currentLrcIndex = -1
        scrollLyrics.removeAllViews(); scrollLyrics.addView(tvLyrics)
        tvLyrics.text = "Buscando \"$query\"…"
        scrollLyrics.scrollTo(0, 0)

        Thread {
            val lrc = fetchLrcLib(query, "")
            if (lrc != null && lrc.contains("[")) {
                val parsed = parseLrc(lrc)
                if (parsed.size >= 3) {
                    if (isDestroyed || isFinishing) return@Thread
                    handler.post {
                        if (isDestroyed || isFinishing) return@post
                        lrcLines = parsed; lrcActive = true; btnToggleScroll.text = "Sync ✓"
                        showLrcLines()
                    }
                    return@Thread
                }
            }
            val plain = fetchLyricsVercel(query)
            if (isDestroyed || isFinishing) return@Thread
            handler.post {
                if (isDestroyed || isFinishing) return@post
                scrollLyrics.removeAllViews(); scrollLyrics.addView(tvLyrics)
                if (plain != null) {
                    tvLyrics.text = plain; autoScrollEnabled = true; btnToggleScroll.text = "Pausar"
                    handler.postDelayed({ if (autoScrollEnabled) startAutoScroll() }, 800)
                } else {
                    tvLyrics.text = "No se encontró la letra de:\n\n\"$query\""
                }
            }
        }.start()
    }

    /** lrclib.net — devuelve el campo syncedLyrics (LRC) o plainLyrics */
    private fun fetchLrcLib(title: String, artist: String): String? {
        return try {
            val q = java.net.URLEncoder.encode(
                if (artist.isNotEmpty()) "$title $artist" else title, "UTF-8"
            )
            val conn = URL("https://lrclib.net/api/search?q=$q")
                .openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "FrikiMusic/1.0")
            conn.connectTimeout = 10000; conn.readTimeout = 10000
            val arr = org.json.JSONArray(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            if (arr.length() == 0) return null
            val first = arr.getJSONObject(0)
            // Preferir syncedLyrics (con timestamps), caer a plainLyrics
            first.optString("syncedLyrics").takeIf { it.isNotEmpty() }
                ?: first.optString("plainLyrics").takeIf { it.isNotEmpty() }
        } catch (e: Exception) { null }
    }

    private fun fetchLyricsVercel(title: String): String? {
        return try {
            val q = java.net.URLEncoder.encode(title, "UTF-8")
            val conn = URL("$VERCEL_API/api/lyrics?q=$q").openConnection() as HttpURLConnection
            conn.setRequestProperty("Accept", "application/json")
            conn.connectTimeout = 15000; conn.readTimeout = 15000
            val resp = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            if (resp.optBoolean("success") || resp.optString("status") == "ok")
                resp.optString("lyrics").takeIf { it.isNotEmpty() }
                    ?: resp.optString("text").takeIf { it.isNotEmpty() }
            else null
        } catch (e: Exception) { null }
    }

    // ─────────────────────────── Auto scroll plano ───────────────────────────

    private fun startAutoScroll() {
        stopAutoScroll()
        autoScrollRunnable = object : Runnable {
            override fun run() {
                if (!autoScrollEnabled || !lyricsVisible || isDestroyed || isFinishing) return
                val maxScroll = scrollLyrics.getChildAt(0)?.height?.minus(scrollLyrics.height) ?: 0
                if (scrollLyrics.scrollY < maxScroll) {
                    scrollLyrics.smoothScrollBy(0, 2)
                    handler.postDelayed(this, 50)
                } else {
                    autoScrollEnabled = false; btnToggleScroll.text = "Scroll"
                }
            }
        }
        handler.postDelayed(autoScrollRunnable!!, 50)
    }

    private fun stopAutoScroll() {
        autoScrollRunnable?.let { handler.removeCallbacks(it) }
        autoScrollRunnable = null
    }

    // ─────────────────────────── UI ───────────────────────────

    private fun applyDuration(dur: Int) {
        if (dur <= 0) return
        seekBar.max = dur
        tvTotalTime.text = formatTime(dur.toLong())
    }

    private fun updateUI() {
        val svc  = musicService ?: return
        val song = svc.getCurrentSong() ?: return
        tvTitle.text  = song.getTitleDisplay()
        tvArtist.text = song.getArtistDisplay()
        val dur = svc.getDuration().takeIf { it > 0 } ?: song.duration.toInt()
        applyDuration(dur)
        btnSaveOffline.visibility = if (song.isStreaming) View.VISIBLE else View.GONE
        Thread {
            val art = song.getAlbumArt()
            if (isDestroyed || isFinishing) return@Thread
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (art != null) { imgAlbum.setImageBitmap(art); imgAlbum.scaleType = ImageView.ScaleType.CENTER_CROP }
                else { imgAlbum.setImageResource(android.R.drawable.ic_media_play); imgAlbum.scaleType = ImageView.ScaleType.CENTER }
            }
        }.start()
        btnPlayPause.setImageResource(if (svc.isPlaying()) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun startSeekUpdater() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isDestroyed || isFinishing) return
                val svc = musicService
                if (isBound && svc != null) {
                    val pos = svc.getCurrentPosition()
                    val dur = svc.getDuration()
                    if (dur > 0) applyDuration(dur)
                    seekBar.progress = pos
                    tvCurrentTime.text = formatTime(pos.toLong())
                    if (svc.isPlaying()) btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                }
                handler.postDelayed(this, 500)
            }
        }, 500)
    }

    private fun downloadSong(song: Song) {
        btnSaveOffline.text = "Descargando..."; btnSaveOffline.isEnabled = false
        Thread {
            try {
                val body = org.json.JSONObject().apply {
                    put("url", "https://www.youtube.com/watch?v=${song.videoId}"); put("format", "mp3")
                }.toString()
                val conn = URL("$VERCEL_API/api/app-download").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true; conn.connectTimeout = 30000; conn.readTimeout = 120000
                conn.outputStream.write(body.toByteArray())
                val resp = org.json.JSONObject(conn.inputStream.bufferedReader().readText()); conn.disconnect()
                val relativeUrl = resp.optString("url").takeIf { it.isNotEmpty() } ?: throw Exception("No URL")
                val streamUrl = "$VERCEL_API$relativeUrl"
                val title  = song.getTitleDisplay()
                val artist = song.getArtistDisplay()
                val downloadDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                downloadDir.mkdirs()
                val safeName = title.replace(Regex("[<>:\"/\\\\|?*]"), "").take(60)
                val tmpFile  = File(downloadDir, "$safeName.tmp")
                val finalFile = File(downloadDir, "$safeName.mp3")
                val dlConn = URL(streamUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60000; dlConn.readTimeout = 180000
                val totalBytes = dlConn.contentLength.toLong()
                dlConn.inputStream.use { i -> FileOutputStream(tmpFile).use { o ->
                    val buf = ByteArray(8192); var dl = 0L; var n: Int
                    while (i.read(buf).also { n = it } != -1) { o.write(buf, 0, n); dl += n
                        if (totalBytes > 0 && !isDestroyed) handler.post { if (!isDestroyed) btnSaveOffline.text = "${(dl*100/totalBytes).toInt()}%" }
                    }
                }}; dlConn.disconnect()
                try {
                    val mp3 = com.mpatric.mp3agic.Mp3File(tmpFile)
                    val tag = com.mpatric.mp3agic.ID3v24Tag()
                    tag.title = title; tag.artist = artist; tag.album = artist
                    if (song.videoId.isNotEmpty()) {
                        try {
                            val artConn = URL("https://img.youtube.com/vi/${song.videoId}/hqdefault.jpg").openConnection() as HttpURLConnection
                            artConn.connectTimeout = 8000; artConn.readTimeout = 8000
                            tag.setAlbumImage(artConn.inputStream.readBytes(), "image/jpeg"); artConn.disconnect()
                        } catch (e: Exception) {}
                    }
                    mp3.id3v2Tag = tag; mp3.save(finalFile.absolutePath); tmpFile.delete()
                } catch (e: Exception) { tmpFile.renameTo(finalFile) }
                android.media.MediaScannerConnection.scanFile(this, arrayOf(finalFile.absolutePath), arrayOf("audio/mpeg"), null)
                sendBroadcast(Intent("com.musicplayer.SONG_ADDED"))
                val sizeMb = String.format("%.1f", finalFile.length() / 1024f / 1024f)
                if (isDestroyed || isFinishing) return@Thread
                handler.post {
                    if (!isDestroyed) { btnSaveOffline.text = "Guardado ($sizeMb MB)"
                        Toast.makeText(this, "Guardado: $safeName", Toast.LENGTH_LONG).show()
                        handler.postDelayed({ if (!isDestroyed) { btnSaveOffline.text = "Guardar"; btnSaveOffline.isEnabled = true } }, 3000)
                    }
                }
            } catch (e: Exception) {
                if (isDestroyed || isFinishing) return@Thread
                handler.post { if (!isDestroyed) { btnSaveOffline.text = "Error"
                    Toast.makeText(this, "Error: ${e.message?.take(60)}", Toast.LENGTH_SHORT).show()
                    handler.postDelayed({ if (!isDestroyed) { btnSaveOffline.text = "Guardar"; btnSaveOffline.isEnabled = true } }, 3000)
                }}
            }
        }.start()
    }

    private fun formatTime(ms: Long): String {
        val s = (ms / 1000) % 60; val m = (ms / 60000) % 60
        return "%d:%02d".format(m, s)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBackPressed() { if (lyricsVisible) hideLyrics() else super.onBackPressed() }

    override fun onDestroy() {
        super.onDestroy()
        stopAutoScroll(); stopLrcSync()
        durationReceiver?.let { unregisterReceiver(it) }
        songChangedReceiver?.let { unregisterReceiver(it) }
        if (isBound) { unbindService(serviceConnection); isBound = false }
        handler.removeCallbacksAndMessages(null)
    }
}