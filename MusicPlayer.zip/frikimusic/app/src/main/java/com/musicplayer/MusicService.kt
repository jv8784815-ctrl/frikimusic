package com.musicplayer

import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.*
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import androidx.media.session.MediaButtonReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MusicService : Service() {

    companion object {
        const val CHANNEL_ID   = "music_channel"
        const val NOTIF_ID     = 1
        const val ACTION_PLAY  = "com.musicplayer.PLAY"
        const val ACTION_PAUSE = "com.musicplayer.PAUSE"
        const val ACTION_NEXT  = "com.musicplayer.NEXT"
        const val ACTION_PREV  = "com.musicplayer.PREV"
        const val ACTION_FWD   = "com.musicplayer.FWD"
        const val ACTION_RWD   = "com.musicplayer.RWD"
    }

    private var player: MediaPlayer? = null
    private var songList = ArrayList<Song>()
    private var currentIndex = 0
    private val binder = MusicBinder()
    private lateinit var mediaSession: MediaSessionCompat
    private val handler = Handler(Looper.getMainLooper())
    private var isPreparing = false
    var streamSource: String = ""
    private var cachedDuration: Int = 0

    inner class MusicBinder : Binder() {
        fun getService(): MusicService = this@MusicService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initPlayer()
        mediaSession = MediaSessionCompat(this, "FrikiMusic")
        mediaSession.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay()            { play() }
            override fun onPause()           { pause() }
            override fun onSkipToNext()      { next() }
            override fun onSkipToPrevious()  { previous() }
            override fun onSeekTo(pos: Long) { seekTo(pos.toInt()) }
        })
        mediaSession.isActive = true
    }

    private fun initPlayer() {
        player?.release()
        cachedDuration = 0
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setOnCompletionListener { next() }
            setOnPreparedListener { mp ->
                isPreparing = false
                mp.start()
                updateNotification()
                startProgressUpdater()
                val durImmediate = mp.duration
                if (durImmediate > 0) {
                    cachedDuration = durImmediate
                    broadcastDuration(durImmediate.toLong())
                } else {
                    startDurationPolling(mp)
                }
            }
            setOnErrorListener { _, _, _ ->
                isPreparing = false
                handler.post { updateNotifStatus("Error al reproducir") }
                true
            }
            setOnInfoListener { _, what, _ ->
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START)
                    handler.post { updateNotifStatus("Buffering...") }
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END)
                    handler.post { updateNotification() }
                false
            }
        }
    }

    private fun startDurationPolling(mp: MediaPlayer) {
        var attempts = 0
        val maxAttempts = 20
        val pollRunnable = object : Runnable {
            override fun run() {
                if (attempts >= maxAttempts || player != mp) return
                val dur = try { mp.duration } catch (e: Exception) { -1 }
                if (dur > 0) {
                    cachedDuration = dur
                    broadcastDuration(dur.toLong())
                } else {
                    attempts++
                    handler.postDelayed(this, 500)
                }
            }
        }
        handler.postDelayed(pollRunnable, 500)
    }

    private fun broadcastDuration(duration: Long) {
        sendBroadcast(Intent("com.musicplayer.DURATION_READY").apply {
            putExtra("duration", duration)
        })
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY  -> play()
            ACTION_PAUSE -> pause()
            ACTION_NEXT  -> next()
            ACTION_PREV  -> previous()
            ACTION_FWD   -> seekTo((getCurrentPosition() + 10000).coerceAtMost(getDuration()))
            ACTION_RWD   -> seekTo((getCurrentPosition() - 10000).coerceAtLeast(0))
        }
        MediaButtonReceiver.handleIntent(mediaSession, intent)
        return START_STICKY
    }

    fun setSongList(list: ArrayList<Song>) { songList = list }

    fun playSongAt(index: Int) {
        sendBroadcast(Intent("com.musicplayer.SONG_CHANGED").apply {
            putExtra("index", index)
        })
        if (songList.isEmpty() || index < 0 || index >= songList.size) return
        currentIndex = index
        val song = songList[index]
        isPreparing = false
        initPlayer()

        if (song.isStreaming) {
            handler.post { updateNotifStatus("Obteniendo stream...") }
            Thread {
                val streamUrl = getStreamUrl(song.videoId)
                if (streamUrl != null) {
                    handler.post {
                        try {
                            player?.setDataSource(streamUrl)
                            isPreparing = true
                            player?.prepareAsync()
                            updateNotifStatus("Buffering...")
                        } catch (e: Exception) {
                            updateNotifStatus("Error al cargar")
                        }
                    }
                } else {
                    handler.post { updateNotifStatus("No se pudo obtener stream") }
                }
            }.start()
        } else {
            try {
                player?.setDataSource(song.path)
                player?.prepare()
                player?.start()
                val dur = player?.duration ?: 0
                if (dur > 0) {
                    cachedDuration = dur
                    broadcastDuration(dur.toLong())
                }
                updateNotification()
                startProgressUpdater()
            } catch (e: Exception) {
                handler.post { updateNotifStatus("Error") }
            }
        }
    }

    private fun getStreamUrl(videoId: String): String? {

        // ── Obtener URL del tunnel desde GitHub Gist ──
        var tunnelUrl = ""
        try {
            val conn = java.net.URL("https://gist.githubusercontent.com/jv8784815-ctrl/020306f12721bdba9314ea0559008d11/raw/tunnel.json")
                .openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val resp = JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            tunnelUrl = resp.optString("tunnel").trimEnd('/')
            android.util.Log.d("MusicService", "🌐 Tunnel: $tunnelUrl")
        } catch (e: Exception) {
            android.util.Log.e("MusicService", "Error obteniendo tunnel URL: ${e.message}")
        }

        // ── 1. Tunnel Cloudflare directo -> /api/download + polling ──
        if (tunnelUrl.isNotEmpty()) {
            try {
                val body = JSONObject().apply {
                    put("url", "https://www.youtube.com/watch?v=$videoId")
                    put("format", "mp3")
                }.toString()

                val conn = java.net.URL("$tunnelUrl/api/download")
                    .openConnection() as java.net.HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.outputStream.write(body.toByteArray())

                val resp = JSONObject(conn.inputStream.bufferedReader().readText())
                conn.disconnect()

                val taskId = resp.optString("task_id").takeIf { it.isNotEmpty() }
                if (taskId != null) {
                    android.util.Log.d("MusicService", "✅ taskId=$taskId polling...")
                    var attempts = 0
                    while (attempts < 60) {
                        Thread.sleep(3000)
                        attempts++
                        try {
                            val statusConn = java.net.URL("$tunnelUrl/api/status/$taskId")
                                .openConnection() as java.net.HttpURLConnection
                            statusConn.connectTimeout = 10000
                            statusConn.readTimeout = 10000
                            val status = JSONObject(statusConn.inputStream.bufferedReader().readText())
                            statusConn.disconnect()
                            when (status.optString("status")) {
                                "completed" -> {
                                    val streamUrl = status.optString("stream_url").takeIf { it.isNotEmpty() }
                                    if (streamUrl != null) {
                                        streamSource = "Tunnel"
                                        android.util.Log.d("MusicService", "✅ Stream listo: $tunnelUrl$streamUrl")
                                        return "$tunnelUrl$streamUrl"
                                    }
                                }
                                "failed" -> {
                                    android.util.Log.e("MusicService", "❌ Download failed: ${status.optString("error")}")
                                    break
                                }
                            }
                        } catch (e: Exception) {
                            android.util.Log.w("MusicService", "Polling error: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("MusicService", "Tunnel download error: ${e.message}")
            }
        }

        // ── 2. Fallback: FrikiAPI Python directo ──
        try {
            val body = JSONObject().apply {
                put("url", "https://www.youtube.com/watch?v=$videoId")
                put("quality", "96")
                put("apikey", "friki_ebddef50f2754a0182a51d781006fc4c")
            }.toString()
            val conn = java.net.URL("http://64.20.54.50:30325/api/ytmp3")
                .openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 300000
            conn.outputStream.write(body.toByteArray())
            val resp = JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()
            if (resp.optBoolean("success") && resp.has("dl")) {
                streamSource = "FrikiAPI"
                return resp.getString("dl")
            }
        } catch (e: Exception) { }

        return null
    }


    fun play() {
        val p = player ?: return
        if (!p.isPlaying && !isPreparing) {
            if (p.currentPosition == 0 && songList.isNotEmpty()) playSongAt(currentIndex)
            else { p.start(); updateNotification(); startProgressUpdater() }
        }
    }

    fun pause() {
        player?.takeIf { it.isPlaying }?.pause()
        updateNotification()
    }

    fun next() {
        if (songList.isEmpty()) return
        currentIndex = (currentIndex + 1) % songList.size
        playSongAt(currentIndex)
    }

    fun previous() {
        if (songList.isEmpty()) return
        currentIndex = (currentIndex - 1 + songList.size) % songList.size
        playSongAt(currentIndex)
    }

    fun isPlaying() = player?.isPlaying ?: false
    fun getCurrentPosition() = if (isPreparing) 0 else (player?.currentPosition ?: 0)

    fun getDuration(): Int {
        if (isPreparing) return 0
        val raw = player?.duration ?: 0
        return when {
            raw > 0 -> { cachedDuration = raw; raw }
            cachedDuration > 0 -> cachedDuration
            else -> 0
        }
    }

    fun getCurrentSong() = songList.getOrNull(currentIndex)
    fun seekTo(pos: Int)  { if (!isPreparing) player?.seekTo(pos); updateNotification() }

    private fun startProgressUpdater() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (isPlaying()) {
                    updateMediaSessionState()
                    updateNotification()
                    handler.postDelayed(this, 1000)
                }
            }
        }, 1000)
    }

    private fun updateMediaSessionState() {
        val state = if (isPlaying()) PlaybackStateCompat.STATE_PLAYING
        else PlaybackStateCompat.STATE_PAUSED
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                            PlaybackStateCompat.ACTION_PAUSE or
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackStateCompat.ACTION_SEEK_TO
                )
                .setState(state, getCurrentPosition().toLong(), 1f)
                .build()
        )
        val song = getCurrentSong() ?: return
        val metaBuilder = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE,  song.getTitleDisplay())
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.getArtistDisplay())
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, getDuration().toLong())
        Thread {
            val art = song.getAlbumArt()
            if (art != null) metaBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
            mediaSession.setMetadata(metaBuilder.build())
        }.start()
    }

    private fun actionIntent(action: String): PendingIntent {
        val i = Intent(this, MusicService::class.java).apply { this.action = action }
        return PendingIntent.getService(this, action.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun updateNotifStatus(status: String) {
        val song = getCurrentSong() ?: return
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song.getTitleDisplay())
            .setContentText(status)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
        startForeground(NOTIF_ID, builder.build())
    }

    fun updateNotification() {
        val song = getCurrentSong() ?: return
        updateMediaSessionState()

        val openPlayer = PendingIntent.getActivity(
            this, 0, Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon   = if (isPlaying()) android.R.drawable.ic_media_pause
        else android.R.drawable.ic_media_play
        val playPauseAction = if (isPlaying()) ACTION_PAUSE else ACTION_PLAY
        val duration = getDuration()
        val progress = if (duration > 0) (getCurrentPosition() * 100 / duration) else 0

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(song.getTitleDisplay())
            .setContentText(song.getArtistDisplay())
            .setContentIntent(openPlayer)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress, false)
            .addAction(android.R.drawable.ic_media_previous, "Anterior", actionIntent(ACTION_PREV))
            .addAction(android.R.drawable.ic_media_rew,      "-10s",     actionIntent(ACTION_RWD))
            .addAction(playPauseIcon, if (isPlaying()) "Pausar" else "Play", actionIntent(playPauseAction))
            .addAction(android.R.drawable.ic_media_ff,       "+10s",     actionIntent(ACTION_FWD))
            .addAction(android.R.drawable.ic_media_next,     "Siguiente",actionIntent(ACTION_NEXT))
            .setStyle(MediaStyle()
                .setMediaSession(mediaSession.sessionToken)
                .setShowActionsInCompactView(0, 2, 4)
            )

        Thread {
            val art = song.getAlbumArt()
            val notif = if (art != null) builder.setLargeIcon(art).build() else builder.build()
            startForeground(NOTIF_ID, notif)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif)

            val widgetManager = AppWidgetManager.getInstance(this)
            val ids = widgetManager.getAppWidgetIds(
                ComponentName(this, MusicWidget::class.java)
            )
            for (id in ids) {
                MusicWidget.updateWidget(this, widgetManager, id, getCurrentSong(), isPlaying())
            }
        }.start()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Reproductor", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        mediaSession.release()
        player?.release()
        player = null
    }
}