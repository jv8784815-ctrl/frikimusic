package com.musicplayer

import android.content.Context
import android.content.SharedPreferences

object GoogleAuthManager {

    private const val PREFS = "google_auth"
    private const val KEY_TOKEN = "access_token"
    private const val KEY_EMAIL = "email"
    private const val KEY_NAME  = "display_name"
    private const val KEY_SAPISID = "sapisid"

    fun saveAuth(context: Context, token: String, email: String, name: String) {
        prefs(context).edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_EMAIL, email)
            .putString(KEY_NAME, name)
            .apply()
    }

    fun saveSapisid(context: Context, sapisid: String) {
        prefs(context).edit().putString(KEY_SAPISID, sapisid).apply()
    }

    fun getToken(context: Context): String? = prefs(context).getString(KEY_TOKEN, null)
    fun getEmail(context: Context): String? = prefs(context).getString(KEY_EMAIL, null)
    fun getName(context: Context): String?  = prefs(context).getString(KEY_NAME, null)
    fun getSapisid(context: Context): String? = prefs(context).getString(KEY_SAPISID, null)
    fun isLoggedIn(context: Context): Boolean = getToken(context) != null

    fun logout(context: Context) {
        prefs(context).edit().clear().apply()
    }

    fun getAuthHeaders(context: Context): Map<String, String> {
        val token = getToken(context) ?: return emptyMap()
        val sapisid = getSapisid(context)
        val headers = mutableMapOf(
            "Authorization" to "Bearer $token",
            "X-Goog-AuthUser" to "0",
            "Cookie" to "SAPISID=$sapisid; __Secure-3PAPISID=$sapisid"
        )
        if (sapisid != null) {
            val ts = System.currentTimeMillis() / 1000
            val hash = sha1("$ts $sapisid https://music.youtube.com")
            headers["Authorization"] = "SAPISIDHASH ${ts}_${hash}"
        }
        return headers
    }

    private fun sha1(input: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        val bytes = md.digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}